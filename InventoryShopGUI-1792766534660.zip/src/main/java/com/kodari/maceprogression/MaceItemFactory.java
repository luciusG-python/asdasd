package com.kodari.maceprogression;

import com.cryptomorin.xseries.XMaterial;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.UUID;

/** Creates and validates owner-bound tier mace items. */
public final class MaceItemFactory {
    private final MaceProgressionPlugin plugin;
    private final NamespacedKey tierKey;
    private final NamespacedKey ownerKey;
    private final NamespacedKey idKey;
    private final MaceLoreBuilder loreBuilder;

    public MaceItemFactory(MaceProgressionPlugin plugin) {
        this.plugin = plugin;
        this.tierKey = new NamespacedKey(plugin, "tier");
        this.ownerKey = new NamespacedKey(plugin, "owner");
        this.idKey = new NamespacedKey(plugin, "mace_id");
        this.loreBuilder = new MaceLoreBuilder(plugin);
    }

    public ItemStack create(Player owner, MaceTier tier, PlayerProgress progress) {
        ItemStack item = XMaterial.matchXMaterial("MACE").map(XMaterial::parseItem).orElseThrow();
        ItemMeta meta = item.getItemMeta();
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(tierKey, PersistentDataType.STRING, tier.name());
        pdc.set(ownerKey, PersistentDataType.STRING, owner.getUniqueId().toString());
        pdc.set(idKey, PersistentDataType.STRING, UUID.randomUUID().toString());
        item.setItemMeta(meta);
        update(item, tier, progress);
        return item;
    }

    public void update(ItemStack item, MaceTier tier, PlayerProgress progress) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;
        meta.getPersistentDataContainer().set(tierKey, PersistentDataType.STRING, tier.name());
        meta.setItemModel(tier == MaceTier.DEFAULT ? null : new NamespacedKey("maceprogression", tier.key() + "_mace"));
        for (Enchantment enchantment : new ArrayList<>(meta.getEnchants().keySet())) meta.removeEnchant(enchantment);
        applyConfiguredEnchants(meta, tier);
        loreBuilder.apply(meta, tier, progress);
        item.setItemMeta(meta);
    }

    public boolean isPluginMace(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(tierKey, PersistentDataType.STRING)
                && item.getItemMeta().getPersistentDataContainer().has(ownerKey, PersistentDataType.STRING)
                && item.getItemMeta().getPersistentDataContainer().has(idKey, PersistentDataType.STRING);
    }

    public boolean isOwnedBy(ItemStack item, UUID owner) {
        return isPluginMace(item) && owner.toString().equals(item.getItemMeta().getPersistentDataContainer().get(ownerKey, PersistentDataType.STRING));
    }

    public MaceTier tierOf(ItemStack item) {
        if (!isPluginMace(item)) return null;
        return MaceTier.parse(item.getItemMeta().getPersistentDataContainer().get(tierKey, PersistentDataType.STRING));
    }

    public String uniqueId(ItemStack item) {
        if (!isPluginMace(item)) return null;
        return item.getItemMeta().getPersistentDataContainer().get(idKey, PersistentDataType.STRING);
    }

    private void applyConfiguredEnchants(ItemMeta meta, MaceTier tier) {
        var section = plugin.getConfig().getConfigurationSection("enchantments." + tier.key());
        if (section == null) return;
        for (String key : section.getKeys(false)) {
            Enchantment enchantment = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(key.toLowerCase(java.util.Locale.ROOT)));
            if (enchantment != null) meta.addEnchant(enchantment, Math.max(1, section.getInt(key, 1)), true);
            else plugin.getLogger().warning("Unknown enchantment registry key in config: " + key);
        }
    }

}
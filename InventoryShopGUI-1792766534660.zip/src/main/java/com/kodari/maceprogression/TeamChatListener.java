package com.kodari.maceprogression;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import io.papermc.paper.chat.ChatRenderer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public final class TeamChatListener implements Listener {
    private final TeamManager teams;

    public TeamChatListener(TeamManager teams) {
        this.teams = teams;
    }

    @EventHandler
    public void onChat(AsyncChatEvent event) {
        String teamName = teams.teamName(event.getPlayer().getUniqueId());
        if (teamName == null) return;
        ChatRenderer existing = event.renderer();
        Component prefix = Component.text(teamName + " | ", NamedTextColor.GRAY);
        event.renderer((source, sourceDisplayName, message, viewer) ->
                prefix.append(existing.render(source, sourceDisplayName, message, viewer)));
    }
}
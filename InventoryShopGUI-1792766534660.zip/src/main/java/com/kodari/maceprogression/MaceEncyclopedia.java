package com.kodari.maceprogression;

import com.cryptomorin.xseries.XEnchantment;
import com.cryptomorin.xseries.XMaterial;
import com.cryptomorin.xseries.XSound;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.InventoryPickupItemEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Builds the read-only mace reference menu and removes any leaked display icons. */
public final class MaceEncyclopedia implements Listener {
    private static final int[] TIER_SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20};
    private static final int INFO_SLOT = 31;
    private static final int CLOSE_SLOT = 49;
    private static final List<String> STAT_FIELDS = List.of("damage", "distance", "earthquake_radius", "shockwave_radius",
            "duration", "amplifier", "speed_amplifier", "absorption_amplifier", "resistance_amplifier",
            "regeneration_amplifier", "knockback", "velocity", "chance");

    private final MaceProgressionPlugin plugin;
    private final NamespacedKey displayItemKey;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();
    private final BukkitTask cleanupTask;

    public MaceEncyclopedia(MaceProgressionPlugin plugin) {
        this.plugin = plugin;
        this.displayItemKey = new NamespacedKey(plugin, "mace_gui_item");
        this.cleanupTask = Bukkit.getScheduler().runTaskTimer(plugin, this::sweepPlayers, 100L, 100L);
    }

    public void open(Player player) {
        cleanupPlayer(player);
        MaceGuiHolder holder = new MaceGuiHolder(player.getUniqueId());
        Inventory inventory = Bukkit.createInventory(holder, 54, text("title", "<gradient:#ff5555:#55ffff>Mace Encyclopedia</gradient>"));
        holder.setInventory(inventory);
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            if (isBorder(slot)) inventory.setItem(slot, createPane());
        }

        PlayerProgress progress = plugin.playerData().get(player.getUniqueId());
        MaceTier[] tiers = MaceTier.values();
        for (int index = 0; index < tiers.length; index++) {
            inventory.setItem(TIER_SLOTS[index], createTierItem(player, tiers[index], progress));
        }
        inventory.setItem(INFO_SLOT, createInfoItem());
        inventory.setItem(CLOSE_SLOT, createCloseItem());
        XSound.matchXSound(plugin.getConfig().getString("mace_encyclopedia.open_sound", "BLOCK_CHEST_OPEN"))
                .ifPresent(sound -> sound.play(player));
        player.openInventory(inventory);
    }

    public void shutdown() {
        cleanupTask.cancel();
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (isEncyclopedia(player.getOpenInventory().getTopInventory())) player.closeInventory();
            cleanupPlayer(player);
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        boolean encyclopediaOpen = isEncyclopedia(top) || isEncyclopedia(event.getClickedInventory());
        if (encyclopediaOpen) {
            event.setCancelled(true);
            event.setResult(Event.Result.DENY);
            if (!(event.getWhoClicked() instanceof Player player)) return;
            MaceGuiHolder holder = menuHolder(top);
            if (holder == null || !holder.viewer().equals(player.getUniqueId())) return;
            int rawSlot = event.getRawSlot();
            if (rawSlot == CLOSE_SLOT) {
                player.closeInventory();
            } else if (isTierSlot(rawSlot)) {
                XSound.matchXSound(plugin.getConfig().getString("mace_encyclopedia.tier_click_sound", "UI_BUTTON_CLICK"))
                        .ifPresent(sound -> sound.play(player));
            }
            return;
        }

        ItemStack current = event.getCurrentItem();
        ItemStack cursor = event.getCursor();
        Player player = event.getWhoClicked() instanceof Player clicker ? clicker : null;
        ItemStack hotbar = player != null && event.getHotbarButton() >= 0
                ? player.getInventory().getItem(event.getHotbarButton()) : null;
        ItemStack offhand = event.getClick() == org.bukkit.event.inventory.ClickType.SWAP_OFFHAND && player != null
                ? player.getInventory().getItemInOffHand() : null;
        if (!isTagged(current) && !isTagged(cursor) && !isTagged(hotbar) && !isTagged(offhand)) return;
        event.setCancelled(true);
        event.setResult(Event.Result.DENY);
        if (isTagged(current)) event.setCurrentItem(null);
        if (isTagged(cursor)) event.setCursor(null);
        if (player != null && event.getHotbarButton() >= 0 && isTagged(hotbar)) {
            player.getInventory().setItem(event.getHotbarButton(), null);
        }
        if (player != null && isTagged(offhand)) player.getInventory().setItemInOffHand(null);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        Inventory top = event.getView().getTopInventory();
        boolean menuOpen = isEncyclopedia(top) || isEncyclopedia(event.getInventory());
        if (menuOpen) {
            event.setCancelled(true);
            event.setResult(Event.Result.DENY);
            return;
        }
        boolean taggedCursor = isTagged(event.getOldCursor())
                || event.getNewItems().values().stream().anyMatch(this::isTagged);
        if (!taggedCursor) return;
        event.setCancelled(true);
        event.setResult(Event.Result.DENY);
        event.setCursor(null);
    }

    @EventHandler
    public void onInventoryMove(InventoryMoveItemEvent event) {
        boolean menuInventory = isEncyclopedia(event.getSource()) || isEncyclopedia(event.getDestination());
        if (!menuInventory && !isTagged(event.getItem())) return;
        event.setCancelled(true);
        if (!menuInventory && isTagged(event.getItem())) removeTaggedItems(event.getSource());
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (isEncyclopedia(event.getInventory()) && event.getPlayer() instanceof Player player) cleanupPlayer(player);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent event) {
        boolean menuOpen = isEncyclopedia(event.getPlayer().getOpenInventory().getTopInventory());
        if (menuOpen || isTagged(event.getItemDrop().getItemStack())) event.setCancelled(true);
        if (isTagged(event.getItemDrop().getItemStack())) event.getItemDrop().remove();
        if (menuOpen) cleanupPlayer(event.getPlayer());
    }

    @EventHandler
    public void onPickup(EntityPickupItemEvent event) {
        if (!isTagged(event.getItem().getItemStack())) return;
        event.setCancelled(true);
        event.getItem().remove();
    }

    @EventHandler
    public void onInventoryPickup(InventoryPickupItemEvent event) {
        boolean menuInventory = isEncyclopedia(event.getInventory());
        if (!menuInventory && !isTagged(event.getItem().getItemStack())) return;
        event.setCancelled(true);
        if (isTagged(event.getItem().getItemStack())) event.getItem().remove();
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (!isTagged(event.getItem()) && !isTagged(player.getInventory().getItemInMainHand())
                && !isTagged(player.getInventory().getItemInOffHand())) return;
        event.setCancelled(true);
        clearTaggedHands(player);
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        if (!isTagged(event.getItemInHand()) && !isTagged(event.getPlayer().getInventory().getItemInOffHand())) return;
        event.setCancelled(true);
        clearTaggedHands(event.getPlayer());
    }

    @EventHandler
    public void onBlockDamage(BlockDamageEvent event) {
        if (!isTagged(event.getItemInHand()) && !isTagged(event.getPlayer().getInventory().getItemInOffHand())) return;
        event.setCancelled(true);
        clearTaggedHands(event.getPlayer());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        cleanupPlayer(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (isEncyclopedia(player.getOpenInventory().getTopInventory())) player.closeInventory();
        cleanupPlayer(player);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        if (isEncyclopedia(player.getOpenInventory().getTopInventory())) player.closeInventory();
        event.getDrops().removeIf(this::isTagged);
        cleanupPlayer(player);
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        Player player = event.getPlayer();
        if (isEncyclopedia(player.getOpenInventory().getTopInventory())) player.closeInventory();
        cleanupPlayer(player);
    }

    private ItemStack createTierItem(Player player, MaceTier tier, PlayerProgress progress) {
        ItemStack item = XMaterial.matchXMaterial("MACE").map(XMaterial::parseItem).orElseThrow();
        ItemMeta meta = item.getItemMeta();
        String tierColor = plugin.getConfig().getString("lore.tier_colors." + tier.key(), "<white>");
        String tierName = plugin.getConfig().getString("mace_encyclopedia.tier_names." + tier.key(), tier.displayName());
        String status = tier == progress.getTier()
                ? text("status_current", "<green>Your current mace")
                : tier.ordinal() < progress.getTier().ordinal()
                ? text("status_unlocked", "<green>Unlocked")
                : text("status_locked", "<red>Locked");
        List<Component> lore = new ArrayList<>();
        lore.add(render(replace(text("tier_line", "<gray>Tier: <white>%tier%"), Map.of("%tier%", tierName))));
        lore.add(render(replace(text("kills_needed_line", "<gray>Kills needed to reach: <white>%kills_needed%"),
                Map.of("%kills_needed%", Integer.toString(killsToReach(tier))))));
        lore.add(render(replace(text("total_kills_line", "<gray>Your total kills: <white>%total_kills%"),
                Map.of("%total_kills%", Integer.toString(progress.getTotalKills())))));
        lore.add(render(replace(text("status_line", "<gray>Status: %status%"), Map.of("%status%", status))));
        String locatorStatus = plugin.locatorBar().isUnlocked(tier)
                ? text("locator_unlocked", "<green>Unlocked") : text("locator_locked", "<red>Locked");
        lore.add(render(replace(text("locator_line", "<gray>Locator Bar: %locator%"), Map.of("%locator%", locatorStatus))));
        lore.add(Component.empty());
        appendAbilityLore(lore, tier, tierColor);
        if (tier == MaceTier.RAINBOW) {
            lore.add(Component.empty());
            lore.add(render(text("rainbow_trade", "<light_purple>Get it at the Mace Smith: 1 Dragon Egg, 2 Player Heads from different players, and a Netherite Mace.")));
        }
        meta.displayName(render(replace(text("tier_name", "%tier_color%<bold>%tier% Mace"),
                Map.of("%tier_color%", tierColor, "%tier%", tierName))));
        meta.lore(lore);
        meta.setItemModel(tier == MaceTier.DEFAULT ? null : new NamespacedKey("maceprogression", tier.key() + "_mace"));
        if (tier == progress.getTier()) {
            XEnchantment.matchXEnchantment("UNBREAKING").ifPresent(enchantment -> meta.addEnchant(enchantment.getEnchant(), 1, true));
        }
        markDisplayItem(meta);
        item.setItemMeta(meta);
        return item;
    }

    private void appendAbilityLore(List<Component> lore, MaceTier tier, String tierColor) {
        var displaySection = plugin.getConfig().getConfigurationSection("lore.abilities." + tier.key());
        if (displaySection == null) return;
        lore.add(render(text("ability_header", "<gold>Abilities and passives:")));
        int wrapWidth = Math.max(10, plugin.getConfig().getInt("lore.description_wrap", 35));
        List<Ability> activeAbilities = plugin.abilityManager().abilitiesFor(tier);
        for (String key : displaySection.getKeys(false)) {
            var display = displaySection.getConfigurationSection(key);
            if (display == null) continue;
            var mechanics = plugin.getConfig().getConfigurationSection("abilities." + tier.key() + "." + key);
            Ability active = activeAbilities.stream().filter(ability -> ability.key().equals(key)).findFirst().orElse(null);
            Map<String, String> values = new HashMap<>();
            if (mechanics != null) {
                for (String field : mechanics.getKeys(false)) {
                    Object value = mechanics.get(field);
                    if (value != null && !(value instanceof List<?>) && !(value instanceof org.bukkit.configuration.ConfigurationSection)) {
                        values.put("%" + field + "%", String.valueOf(value));
                    }
                }
            }
            for (String field : display.getKeys(false)) {
                Object value = display.get(field);
                if (value != null && !(value instanceof List<?>) && !(value instanceof org.bukkit.configuration.ConfigurationSection)
                        && (!field.equals("cooldown") || mechanics == null || !mechanics.contains("cooldown"))) {
                    values.put("%" + field + "%", String.valueOf(value));
                }
            }
            String name = active == null ? display.getString("name", key) : active.name();
            String trigger = display.getString("trigger", active == null ? "PASSIVE" : active.trigger()).toUpperCase(Locale.ROOT);
            Object configuredCooldown = mechanics != null && mechanics.contains("cooldown")
                    ? mechanics.get("cooldown") : display.get("cooldown");
            if (active != null) configuredCooldown = active.cooldownSeconds();
            String icon = display.getString("icon", "•");
            values.put("%tier_color%", tierColor);
            values.put("%ability_name%", name);
            values.put("%name%", name);
            values.put("%trigger%", trigger);
            values.put("%icon%", icon);
            if (configuredCooldown != null) values.put("%cooldown%", String.valueOf(configuredCooldown));
            Object chance = mechanics == null ? null : mechanics.get("chance");
            if (chance instanceof Number number) values.put("%chance_percent%", Integer.toString((int) Math.round(number.doubleValue() * 100)));

            lore.add(render(replace(text("ability_line", "%tier_color%%icon% %ability_name%: <gray>%trigger%"), values)));
            Object description = display.get("description");
            if (description instanceof List<?> descriptions) {
                for (Object line : descriptions) if (line != null) addWrappedDescription(lore, replace(String.valueOf(line), values), values, wrapWidth);
            } else if (description != null) {
                addWrappedDescription(lore, replace(String.valueOf(description), values), values, wrapWidth);
            }
            String stats = abilityStats(mechanics);
            if (!stats.isBlank()) {
                values.put("%stats%", stats);
                lore.add(render(replace(text("ability_stats_line", "<dark_gray>Stats: <gray>%stats%"), values)));
            }
            if (!trigger.equals("PASSIVE") && configuredCooldown != null) {
                lore.add(render(replace(text("ability_cooldown_line", "<dark_gray>Cooldown: <gray>%cooldown%s"), values)));
            }
        }
    }

    private void addWrappedDescription(List<Component> lore, String description, Map<String, String> values, int width) {
        for (String line : wrap(description, width)) {
            Map<String, String> lineValues = new HashMap<>(values);
            lineValues.put("%description%", line);
            lore.add(render(replace(text("ability_description_line", "<gray>%description%"), lineValues)));
        }
    }

    private String abilityStats(org.bukkit.configuration.ConfigurationSection mechanics) {
        if (mechanics == null) return "";
        List<String> stats = new ArrayList<>();
        for (String field : STAT_FIELDS) {
            Object value = mechanics.get(field);
            if (!(value instanceof Number number)) continue;
            String label = plugin.getConfig().getString("mace_encyclopedia.stat_labels." + field,
                    field.replace('_', ' '));
            String formatted = formatNumber(number.doubleValue());
            if (field.endsWith("amplifier")) {
                label = plugin.getConfig().getString("mace_encyclopedia.stat_labels." + field,
                        field.equals("amplifier") ? "Effect level" : field.replace("_amplifier", " level").replace('_', ' '));
                formatted = Integer.toString(number.intValue() + 1);
            } else if (field.equals("chance")) {
                formatted = Integer.toString((int) Math.round(number.doubleValue() * 100)) + "%";
            }
            stats.add(label + ": " + formatted);
        }
        return String.join(", ", stats);
    }

    private ItemStack createInfoItem() {
        ItemStack item = XMaterial.matchXMaterial("BOOK").map(XMaterial::parseItem).orElseThrow();
        ItemMeta meta = item.getItemMeta();
        meta.displayName(render(text("info_name", "<gold><bold>How progression works")));
        int total = 0;
        List<String> steps = new ArrayList<>();
        MaceTier current = MaceTier.DEFAULT;
        while (current != MaceTier.NETHERITE) {
            int required = plugin.requiredKills(current);
            total += required;
            steps.add(Integer.toString(required));
            current = current.next();
        }
        List<Component> lore = new ArrayList<>();
        for (String line : plugin.getConfig().getStringList("mace_encyclopedia.info_lore")) {
            lore.add(render(replace(line, Map.of("%kills_total%", Integer.toString(total), "%kill_steps%", String.join(", ", steps)))));
        }
        meta.lore(lore);
        markDisplayItem(meta);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack createPane() {
        ItemStack item = XMaterial.matchXMaterial("GRAY_STAINED_GLASS_PANE").map(XMaterial::parseItem).orElseThrow();
        ItemMeta meta = item.getItemMeta();
        meta.displayName(render(text("border_name", "<dark_gray> ")));
        markDisplayItem(meta);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack createCloseItem() {
        ItemStack item = XMaterial.matchXMaterial("BARRIER").map(XMaterial::parseItem).orElseThrow();
        ItemMeta meta = item.getItemMeta();
        meta.displayName(render(text("close_name", "<red>Close")));
        meta.lore(List.of(render(text("close_lore", "<gray>Click to close this menu."))));
        markDisplayItem(meta);
        item.setItemMeta(meta);
        return item;
    }

    private void markDisplayItem(ItemMeta meta) {
        meta.getPersistentDataContainer().set(displayItemKey, PersistentDataType.BYTE, (byte) 1);
    }

    private boolean isTagged(ItemStack item) {
        return item != null && !item.getType().isAir() && item.hasItemMeta()
                && item.getItemMeta().getPersistentDataContainer().has(displayItemKey, PersistentDataType.BYTE);
    }

    private void clearTaggedHands(Player player) {
        if (isTagged(player.getInventory().getItemInMainHand())) player.getInventory().setItemInMainHand(null);
        if (isTagged(player.getInventory().getItemInOffHand())) player.getInventory().setItemInOffHand(null);
    }

    private void cleanupPlayer(Player player) {
        removeTaggedItems(player.getInventory());
        removeTaggedItems(player.getEnderChest());
        if (isTagged(player.getItemOnCursor())) player.setItemOnCursor(null);
        if (isTagged(player.getInventory().getItemInOffHand())) player.getInventory().setItemInOffHand(null);
    }

    private void removeTaggedItems(Inventory inventory) {
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            if (isTagged(inventory.getItem(slot))) inventory.setItem(slot, null);
        }
    }

    private void sweepPlayers() {
        for (Player player : Bukkit.getOnlinePlayers()) cleanupPlayer(player);
    }

    private boolean isEncyclopedia(Inventory inventory) {
        return menuHolder(inventory) != null;
    }

    private MaceGuiHolder menuHolder(Inventory inventory) {
        return inventory != null && inventory.getHolder() instanceof MaceGuiHolder holder ? holder : null;
    }

    private boolean isBorder(int slot) {
        return slot < 9 || slot >= 45 || slot % 9 == 0 || slot % 9 == 8;
    }

    private boolean isTierSlot(int rawSlot) {
        for (int slot : TIER_SLOTS) if (rawSlot == slot) return true;
        return false;
    }

    private int killsToReach(MaceTier target) {
        int total = 0;
        MaceTier current = MaceTier.DEFAULT;
        while (current != target && current != MaceTier.NETHERITE) {
            total += plugin.requiredKills(current);
            current = current.next();
        }
        return total;
    }

    private List<String> wrap(String text, int width) {
        List<String> lines = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : text.trim().split("\\s+")) {
            if (word.isEmpty()) continue;
            if (line.length() > 0 && line.length() + word.length() + 1 > width) {
                lines.add(line.toString());
                line.setLength(0);
            }
            if (line.length() > 0) line.append(' ');
            line.append(word);
        }
        if (line.length() > 0) lines.add(line.toString());
        return lines;
    }

    private String formatNumber(double number) {
        return number == Math.rint(number) ? Long.toString((long) number) : Double.toString(number);
    }

    private String text(String key, String fallback) {
        return plugin.getConfig().getString("mace_encyclopedia." + key, fallback);
    }

    private String replace(String text, Map<String, String> replacements) {
        for (Map.Entry<String, String> replacement : replacements.entrySet()) {
            text = text.replace(replacement.getKey(), replacement.getValue());
        }
        return text;
    }

    private Component render(String text) {
        return miniMessage.deserialize(text);
    }

    private static final class MaceGuiHolder implements InventoryHolder {
        private final UUID viewer;
        private Inventory inventory;

        private MaceGuiHolder(UUID viewer) {
            this.viewer = viewer;
        }

        private UUID viewer() {
            return viewer;
        }

        private void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }
}
package com.kodari.maceprogression;

import com.cryptomorin.xseries.XMaterial;
import com.cryptomorin.xseries.XSound;
import com.cryptomorin.xseries.particles.XParticle;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCreativeEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.InventoryPickupItemEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.inventory.PrepareGrindstoneEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.inventory.PrepareSmithingEvent;
import org.bukkit.event.inventory.SmithItemEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.SkullMeta;

import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/** Handles kill progression, respawn, and common item-transfer/alteration protections. */
public final class MaceListener implements Listener {
    private final MaceProgressionPlugin plugin;
    private final Map<KillPair, Long> victimCooldowns = new HashMap<>();
    private final Map<KillPair, Long> teamKillDowngradeCooldowns = new HashMap<>();
    private final Map<UUID, LastAttacker> recentAttackers = new HashMap<>();
    private final Map<UUID, Long> joinedAt = new HashMap<>();
    private final Map<UUID, DeathMace> deathMaces = new HashMap<>();
    private final Map<UUID, TeamKill> teamKillDeaths = new HashMap<>();
    private final Set<UUID> notifiedTeamKills = new HashSet<>();

    public MaceListener(MaceProgressionPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        joinedAt.put(event.getPlayer().getUniqueId(), System.currentTimeMillis());
        plugin.initializePlayer(event.getPlayer());
        plugin.teamManager().refreshTabName(event.getPlayer());
        plugin.sendResourcePack(event.getPlayer());
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        Entity victimEntity = event.getEntity();
        Player killer = event.getEntity().getKiller();
        LastAttacker lastAttacker = recentAttacker(victimEntity);
        if (killer == null && lastAttacker != null) killer = lastAttacker.player();
        if (killer == null) {
            debug("Kill rejected: no killer for " + victimEntity.getType());
            recentAttackers.remove(victimEntity.getUniqueId());
            return;
        }
        Player victim = victimEntity instanceof Player player ? player : null;
        if (victim != null) {
            if (plugin.teamManager().areTeammates(killer.getUniqueId(), victim.getUniqueId())) {
                boolean ownedMaceAtKill = lastAttacker != null
                        && lastAttacker.player().getUniqueId().equals(killer.getUniqueId())
                        && lastAttacker.ownedMaceAtHit();
                teamKillDeaths.put(victim.getUniqueId(), new TeamKill(killer.getUniqueId(), ownedMaceAtKill));
                notifyTeamKill(killer, victim);
                UUID victimId = victim.getUniqueId();
                Bukkit.getScheduler().runTask(plugin, () -> teamKillDeaths.remove(victimId));
                recentAttackers.remove(victimEntity.getUniqueId());
                return;
            }
            String rejection = playerKillRejection(killer, victim);
            if (rejection != null) {
                rejectKill(killer, rejection);
                recentAttackers.remove(victimEntity.getUniqueId());
                return;
            }
        } else if (!plugin.getConfig().getBoolean("count_mob_kills", false)) {
            rejectKill(killer, "mob kills are disabled");
            recentAttackers.remove(victimEntity.getUniqueId());
            return;
        }
        if (plugin.getConfig().getBoolean("require_mace_kill", true)
                && (lastAttacker == null || !lastAttacker.player().getUniqueId().equals(killer.getUniqueId())
                || !lastAttacker.ownedMaceAtHit())) {
            ItemStack held = lastAttacker != null && lastAttacker.player().getUniqueId().equals(killer.getUniqueId())
                    ? lastAttacker.itemAtHit() : killer.getInventory().getItemInMainHand();
            rejectKill(killer, plugin.itemFactory().isPluginMace(held)
                    ? "the mace is not yours" : "you must be holding your own mace");
            recentAttackers.remove(victimEntity.getUniqueId());
            return;
        }
        recentAttackers.remove(victimEntity.getUniqueId());
        recordKill(killer);
        PlayerProgress progress = plugin.playerData().get(killer.getUniqueId());
        debug("Kill accepted: " + killer.getName() + " defeated " + victimEntity.getName()
                + "; tier=" + progress.getTier() + ", total=" + progress.getTotalKills()
                + ", progress=" + progress.getKillsTowardNextTier());
        if (victim != null && antiFarmingEnabled()) {
            long cooldownMinutes = Math.max(0L, plugin.getConfig().getLong("anti_farming.same_victim_minutes", 2));
            if (cooldownMinutes > 0) {
                victimCooldowns.put(new KillPair(killer.getUniqueId(), victim.getUniqueId()), System.currentTimeMillis());
            }
        }
    }

    @EventHandler(priority = org.bukkit.event.EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        Player attacker = null;
        Entity damager = event.getDamager();
        if (damager instanceof Player player) attacker = player;
        else if (damager instanceof Projectile projectile && projectile.getShooter() instanceof Player player) attacker = player;
        if (attacker != null) {
            ItemStack held = attacker.getInventory().getItemInMainHand();
            recentAttackers.put(event.getEntity().getUniqueId(), new LastAttacker(attacker, System.currentTimeMillis(),
                    plugin.itemFactory().isOwnedBy(held, attacker.getUniqueId()), held.clone()));
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        if (plugin.getConfig().getBoolean("death.player_head.enabled", true)) {
            double chance = Math.max(0.0, Math.min(100.0, plugin.getConfig().getDouble("death.player_head.chance", 100.0)));
            if (ThreadLocalRandom.current().nextDouble(100.0) < chance) {
                ItemStack head = XMaterial.matchXMaterial("PLAYER_HEAD").map(XMaterial::parseItem).orElse(null);
                if (head != null && head.getItemMeta() instanceof SkullMeta skullMeta) {
                    skullMeta.setOwningPlayer(player);
                    head.setItemMeta(skullMeta);
                    event.getDrops().add(head);
                }
            }
        }
        event.getDrops().removeIf(plugin.itemFactory()::isPluginMace);
        int maceSlot = -1;
        ItemStack savedMace = null;
        for (int slot = 0; slot < player.getInventory().getSize(); slot++) {
            ItemStack item = player.getInventory().getItem(slot);
            if (plugin.itemFactory().isOwnedBy(item, player.getUniqueId())) {
                maceSlot = slot;
                savedMace = item.clone();
                break;
            }
        }
        String behavior = plugin.getConfig().getString("death.mode", "DROP_ONE_TIER").toUpperCase(java.util.Locale.ROOT);
        PlayerProgress data = plugin.playerData().get(player.getUniqueId());
        MaceTier before = data.getTier();
        TeamKill teamKill = teamKillDeaths.remove(player.getUniqueId());
        if (teamKill == null) teamKill = resolveTeamKill(player);
        if (teamKill != null) {
            applyTeamKillDowngrade(player, teamKill, data);
        } else {
            switch (behavior) {
                case "KEEP" -> { }
                case "DROP_ONE_TIER" -> {
                    MaceTier downgraded = before;
                    if (before == MaceTier.RAINBOW) {
                        downgraded = MaceTier.parse(plugin.getConfig().getString("death.rainbow_drops_to", "NETHERITE"));
                        if (downgraded == null) downgraded = MaceTier.NETHERITE;
                    } else {
                        int tiersLost = Math.max(0, plugin.getConfig().getInt("death.tiers_lost", 1));
                        for (int tier = 0; tier < tiersLost && downgraded != MaceTier.DEFAULT; tier++) {
                            downgraded = MaceTier.values()[downgraded.ordinal() - 1];
                        }
                    }
                    data.setTier(downgraded);
                    data.setKillsTowardNextTier(0);
                }
                default -> {
                    data.setTier(MaceTier.DEFAULT);
                    data.setKillsTowardNextTier(0);
                }
            }
        }
        if (before != data.getTier()) plugin.locatorBar().apply(player, data.getTier(), true);
        if (teamKill == null && behavior.equals("DROP_ONE_TIER")) {
            String message = plugin.getConfig().getString("messages.death_downgrade", "<red>You died! Your mace dropped to <tier>.");
            player.sendMessage(MiniMessage.miniMessage().deserialize(message.replace("<tier>", data.getTier().displayName())));
        }
        if (savedMace != null) plugin.itemFactory().update(savedMace, data.getTier(), data);
        deathMaces.put(player.getUniqueId(), new DeathMace(maceSlot, savedMace));
        plugin.playerData().save();
    }

    private TeamKill resolveTeamKill(Player victim) {
        Player killer = victim.getKiller();
        LastAttacker lastAttacker = recentAttackers.get(victim.getUniqueId());
        if (killer == null && lastAttacker != null) killer = lastAttacker.player();
        if (killer == null || !plugin.teamManager().areTeammates(killer.getUniqueId(), victim.getUniqueId())) return null;
        boolean ownedMaceAtKill = lastAttacker != null
                && lastAttacker.player().getUniqueId().equals(killer.getUniqueId())
                ? lastAttacker.ownedMaceAtHit()
                : plugin.itemFactory().isOwnedBy(killer.getInventory().getItemInMainHand(), killer.getUniqueId());
        notifyTeamKill(killer, victim);
        return new TeamKill(killer.getUniqueId(), ownedMaceAtKill);
    }

    private void notifyTeamKill(Player killer, Player victim) {
        UUID victimId = victim.getUniqueId();
        if (!notifiedTeamKills.add(victimId)) return;
        killer.sendMessage(MiniMessage.miniMessage().deserialize(
                plugin.getConfig().getString("messages.team_kill_killer", "<red>Team kills do not count.")));
        plugin.getLogger().info("Team kill: " + killer.getName() + " killed teammate " + victim.getName());
        Bukkit.getScheduler().runTaskLater(plugin, () -> notifiedTeamKills.remove(victimId), 1L);
    }

    private void applyTeamKillDowngrade(Player victim, TeamKill teamKill, PlayerProgress data) {
        MaceTier previousTier = data.getTier();
        String messagePath = "messages.team_kill_victim_no_downgrade";
        boolean downgraded = false;
        if (teamKill.ownedMaceAtKill()
                && plugin.getConfig().getBoolean("team_kill.downgrade_victim", true)) {
            int tiersLost = Math.max(0, plugin.getConfig().getInt("team_kill.tiers_lost", 1));
            long cooldownMillis = Math.max(0L, plugin.getConfig().getLong("team_kill.pair_cooldown_seconds", 30)) * 1000L;
            KillPair pair = new KillPair(teamKill.killer(), victim.getUniqueId());
            long now = System.currentTimeMillis();
            long previousKill = teamKillDowngradeCooldowns.getOrDefault(pair, 0L);
            if (previousKill == 0L || cooldownMillis == 0L || now - previousKill >= cooldownMillis) {
                MaceTier tier = previousTier;
                for (int lost = 0; lost < tiersLost && tier != MaceTier.DEFAULT; lost++) {
                    tier = MaceTier.values()[tier.ordinal() - 1];
                }
                if (tier != previousTier) {
                    data.setTier(tier);
                    data.setKillsTowardNextTier(0);
                    teamKillDowngradeCooldowns.put(pair, now);
                    downgraded = true;
                    messagePath = "messages.team_kill_victim";
                }
            } else {
                messagePath = "messages.team_kill_victim_cooldown";
            }
        }
        String message = plugin.getConfig().getString(messagePath,
                downgraded ? "<red>You were killed by a teammate and dropped to <tier>."
                        : "<yellow>You were killed by a teammate; your mace remains at <tier>.");
        victim.sendMessage(MiniMessage.miniMessage().deserialize(message.replace("<tier>", data.getTier().displayName())));
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> {
            DeathMace deathMace = deathMaces.remove(player.getUniqueId());
            if (deathMace != null && deathMace.item() != null) {
                plugin.restoreMaceAtSlot(player, deathMace.slot(), deathMace.item());
            }
            plugin.initializePlayer(player);
        });
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent event) {
        if (plugin.itemFactory().isPluginMace(event.getItemDrop().getItemStack())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(MiniMessage.miniMessage().deserialize("<red>Your mace is soulbound and cannot be dropped."));
        }
    }

    @EventHandler
    public void onPickup(org.bukkit.event.entity.EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        ItemStack item = event.getItem().getItemStack();
        if (plugin.itemFactory().isPluginMace(item)
                && !plugin.itemFactory().isOwnedBy(item, player.getUniqueId())) {
            event.setCancelled(true);
            returnMaceToOnlineOwner(item);
            event.getItem().remove();
        }
        if (plugin.getConfig().getBoolean("block_vanilla_mace_obtaining", true)
                && item.getType().name().equals("MACE") && !plugin.itemFactory().isPluginMace(item)) {
            event.setCancelled(true);
            event.getItem().remove();
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (plugin.villagerManager() != null && plugin.villagerManager().isTradeInventory(event.getView().getTopInventory())
                && event.getRawSlot() == 2) return;
        ItemStack hotbarItem = null;
        if (event.getWhoClicked() instanceof Player player) {
            if (event.getHotbarButton() >= 0) hotbarItem = player.getInventory().getItem(event.getHotbarButton());
            else if (event.getClick() == org.bukkit.event.inventory.ClickType.SWAP_OFFHAND) hotbarItem = player.getInventory().getItemInOffHand();
        }
        boolean protectedItem = plugin.itemFactory().isPluginMace(event.getCurrentItem())
                || plugin.itemFactory().isPluginMace(event.getCursor())
                || plugin.itemFactory().isPluginMace(hotbarItem);
        boolean personalRearrange = event.getWhoClicked() instanceof Player player
                && event.getClickedInventory() instanceof PlayerInventory
                && !event.isShiftClick()
                && (!plugin.itemFactory().isPluginMace(event.getCurrentItem()) || plugin.itemFactory().isOwnedBy(event.getCurrentItem(), player.getUniqueId()))
                && (!plugin.itemFactory().isPluginMace(event.getCursor()) || plugin.itemFactory().isOwnedBy(event.getCursor(), player.getUniqueId()))
                && (!plugin.itemFactory().isPluginMace(hotbarItem) || plugin.itemFactory().isOwnedBy(hotbarItem, player.getUniqueId()));
        if (protectedItem && !personalRearrange) {
            event.setCancelled(true);
            if (event.getWhoClicked() instanceof Player player) {
                notifySoulboundStored(player);
                if (plugin.itemFactory().isPluginMace(event.getCurrentItem())
                        && event.getClickedInventory() != player.getInventory()) {
                    ItemStack stored = event.getCurrentItem();
                    event.setCurrentItem(null);
                    returnMaceToOnlineOwner(stored);
                }
                if (plugin.itemFactory().isPluginMace(event.getCursor())) {
                    ItemStack cursor = event.getCursor();
                    event.setCursor(null);
                    returnMaceToOnlineOwner(cursor);
                }
            }
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (plugin.itemFactory().isPluginMace(event.getOldCursor())) {
            boolean dragsIntoTopInventory = event.getRawSlots().stream().anyMatch(slot -> slot < event.getView().getTopInventory().getSize());
            if (dragsIntoTopInventory) {
                event.setCancelled(true);
                if (event.getWhoClicked() instanceof Player player) notifySoulboundStored(player);
            }
        }
    }

    @EventHandler
    public void onCreative(InventoryCreativeEvent event) {
        if (plugin.itemFactory().isPluginMace(event.getCursor()) || plugin.itemFactory().isPluginMace(event.getCurrentItem())) event.setCancelled(true);
    }

    @EventHandler
    public void onInventoryMove(InventoryMoveItemEvent event) {
        if (!plugin.itemFactory().isPluginMace(event.getItem())) return;
        event.setCancelled(true);
        ItemStack item = event.getItem();
        event.getSource().removeItem(item);
        returnMaceToOnlineOwner(item);
    }

    @EventHandler
    public void onInventoryPickup(InventoryPickupItemEvent event) {
        ItemStack item = event.getItem().getItemStack();
        if (!plugin.itemFactory().isPluginMace(item)) return;
        event.setCancelled(true);
        returnMaceToOnlineOwner(item);
        event.getItem().remove();
    }

    @EventHandler
    public void onInteractEntity(PlayerInteractEntityEvent event) {
        if (!(event.getRightClicked() instanceof ItemFrame frame)) return;
        ItemStack held = event.getPlayer().getInventory().getItem(event.getHand());
        if (plugin.itemFactory().isPluginMace(held)) {
            event.setCancelled(true);
            notifySoulboundStored(event.getPlayer());
        }
        ItemStack framed = frame.getItem();
        if (plugin.itemFactory().isPluginMace(framed)) {
            event.setCancelled(true);
            frame.setItem(null);
            returnMaceToOnlineOwner(framed);
        }
    }

    @EventHandler
    public void onArmorStandManipulate(PlayerArmorStandManipulateEvent event) {
        ItemStack held = event.getPlayerItem();
        ItemStack equipped = event.getArmorStandItem();
        if (!plugin.itemFactory().isPluginMace(held) && !plugin.itemFactory().isPluginMace(equipped)) return;
        event.setCancelled(true);
        notifySoulboundStored(event.getPlayer());
        if (plugin.itemFactory().isPluginMace(equipped)) {
            ArmorStand stand = event.getRightClicked();
            stand.getEquipment().setItem(event.getSlot(), null);
            returnMaceToOnlineOwner(equipped);
        }
    }

    @EventHandler
    public void onCraftPrepare(PrepareItemCraftEvent event) {
        if (containsMace(event.getInventory().getMatrix())) event.getInventory().setResult(null);
    }

    @EventHandler
    public void onCraft(CraftItemEvent event) {
        if (containsMace(event.getInventory().getMatrix())) {
            event.setCancelled(true);
            notifyBlocked((Player) event.getWhoClicked());
        }
    }

    @EventHandler
    public void onAnvil(PrepareAnvilEvent event) {
        if (plugin.itemFactory().isPluginMace(event.getInventory().getItem(0)) || plugin.itemFactory().isPluginMace(event.getInventory().getItem(1))) event.setResult(null);
    }

    @EventHandler
    public void onGrindstone(PrepareGrindstoneEvent event) {
        if (plugin.itemFactory().isPluginMace(event.getInventory().getItem(0)) || plugin.itemFactory().isPluginMace(event.getInventory().getItem(1))) event.setResult(null);
    }

    @EventHandler
    public void onSmithPrepare(PrepareSmithingEvent event) {
        if (plugin.itemFactory().isPluginMace(event.getInventory().getInputEquipment())
                || plugin.itemFactory().isPluginMace(event.getInventory().getInputMineral())
                || plugin.itemFactory().isPluginMace(event.getInventory().getInputTemplate())) event.setResult(null);
    }

    @EventHandler
    public void onSmith(SmithItemEvent event) {
        if (plugin.itemFactory().isPluginMace(event.getInventory().getInputEquipment())
                || plugin.itemFactory().isPluginMace(event.getInventory().getInputMineral())
                || plugin.itemFactory().isPluginMace(event.getInventory().getInputTemplate())) event.setCancelled(true);
    }

    @EventHandler
    public void onEnchant(EnchantItemEvent event) {
        if (plugin.itemFactory().isPluginMace(event.getItem())) {
            event.setCancelled(true);
            notifyBlocked(event.getEnchanter());
        }
    }

    private String playerKillRejection(Player killer, Player victim) {
        if (killer.equals(victim)) {
            return "you cannot earn kills by defeating yourself";
        }
        if (!antiFarmingEnabled()) return null;
        if (plugin.getConfig().getBoolean("anti_farming.reject_same_ip", false) && sameIp(killer, victim)) {
            return "kills from the same IP are disabled";
        }
        if (plugin.getConfig().getBoolean("anti_farming.reject_teammates", true)
                && (plugin.teamManager().areTeammates(killer.getUniqueId(), victim.getUniqueId())
                || (killer.getScoreboard().getEntryTeam(killer.getName()) != null
                && killer.getScoreboard().getEntryTeam(killer.getName()).equals(killer.getScoreboard().getEntryTeam(victim.getName()))))) {
            return "teammate kills are disabled";
        }
        long minimum = plugin.getConfig().getLong("anti_farming.minimum_victim_online_seconds", 0) * 1000L;
        if (System.currentTimeMillis() - joinedAt.getOrDefault(victim.getUniqueId(), System.currentTimeMillis()) < minimum) {
            return "the victim has not been online long enough";
        }
        long cooldownMinutes = Math.max(0L, plugin.getConfig().getLong("anti_farming.same_victim_minutes", 2));
        if (cooldownMinutes == 0) return null;
        long cooldown = cooldownMinutes * 60_000L;
        long now = System.currentTimeMillis();
        KillPair pair = new KillPair(killer.getUniqueId(), victim.getUniqueId());
        long previousKill = victimCooldowns.getOrDefault(pair, 0L);
        long remainingMillis = cooldown - (now - previousKill);
        if (previousKill != 0L && remainingMillis > 0L) {
            long remainingSeconds = (remainingMillis + 999L) / 1000L;
            return "same player killed too recently (" + remainingSeconds + "s left)";
        }
        return null;
    }

    private boolean antiFarmingEnabled() {
        return !plugin.getConfig().getBoolean("test_mode", false)
                && !plugin.getConfig().getBoolean("anti_farming.test_mode", false)
                && plugin.getConfig().getBoolean("anti_farming.enabled", true);
    }

    private void rejectKill(Player killer, String reason) {
        debug("Kill rejected for " + killer.getName() + ": " + reason);
        String message = plugin.getConfig().getString("messages.kill_rejected", "<red>Kill not counted: <reason>");
        killer.sendActionBar(MiniMessage.miniMessage().deserialize(message.replace("<reason>", reason)));
    }

    private boolean sameIp(Player first, Player second) {
        InetSocketAddress firstAddress = first.getAddress();
        InetSocketAddress secondAddress = second.getAddress();
        return firstAddress != null && secondAddress != null
                && firstAddress.getAddress() != null && secondAddress.getAddress() != null
                && firstAddress.getAddress().equals(secondAddress.getAddress());
    }

    public void recordKill(Player killer) {
        PlayerProgress data = plugin.playerData().get(killer.getUniqueId());
        MaceTier previousTier = data.getTier();
        data.setTotalKills(data.getTotalKills() + 1);
        boolean upgraded = false;
        if (data.getTier().ordinal() < MaceTier.NETHERITE.ordinal()) {
            data.setKillsTowardNextTier(data.getKillsTowardNextTier() + 1);
            while (data.getTier().ordinal() < MaceTier.NETHERITE.ordinal()
                    && data.getKillsTowardNextTier() >= plugin.requiredKills(data.getTier())) {
                data.setKillsTowardNextTier(data.getKillsTowardNextTier() - plugin.requiredKills(data.getTier()));
                data.setTier(data.getTier().next());
                upgraded = true;
            }
        }
        plugin.locatorBar().apply(killer, data.getTier(), upgraded);
        if (upgraded) {
            plugin.send(killer, "upgraded", Map.of("tier", data.getTier().displayName()));
            XSound.matchXSound("ENTITY_PLAYER_LEVELUP").ifPresent(sound -> sound.play(killer));
            XParticle.of("HAPPY_VILLAGER").ifPresent(particle -> killer.getWorld().spawnParticle(particle.get(), killer.getLocation().add(0, 1, 0), 24, 0.5, 0.7, 0.5, 0.05));
        } else if (data.getTier() == MaceTier.NETHERITE) {
            plugin.send(killer, "max_tier", Map.of());
        }
        plugin.playerData().save();
        plugin.replaceMace(killer, data.getTier());
        if (previousTier != data.getTier()) {
            debug("Tier upgraded for " + killer.getName() + ": " + previousTier + " -> " + data.getTier()
                    + " after " + data.getTotalKills() + " total kills");
        }
        int required = plugin.requiredKills(data.getTier());
        String requiredText = required == 0 ? "max" : Integer.toString(required);
        String nextName = required == 0 ? "Max" : data.getTier().next().displayName();
        String action = plugin.message("progress").replace("<tier>", data.getTier().displayName())
                .replace("<progress>", Integer.toString(data.getKillsTowardNextTier()))
                .replace("<required>", requiredText).replace("<next>", nextName);
        killer.sendActionBar(MiniMessage.miniMessage().deserialize(action));
    }

    private LastAttacker recentAttacker(Entity victim) {
        LastAttacker last = recentAttackers.get(victim.getUniqueId());
        if (last == null) return null;
        if (System.currentTimeMillis() - last.time() > 5_000L) {
            recentAttackers.remove(victim.getUniqueId());
            return null;
        }
        return last;
    }

    private void debug(String reason) {
        if (plugin.getConfig().getBoolean("debug", false)) plugin.getLogger().info(reason);
    }

    private boolean containsMace(ItemStack[] contents) {
        for (ItemStack item : contents) if (plugin.itemFactory().isPluginMace(item)) return true;
        return false;
    }

    private void notifyBlocked(Player player) {
        player.sendMessage(MiniMessage.miniMessage().deserialize(plugin.getConfig().getString("messages.prefix", "") + plugin.message("blocked")));
    }

    private void notifySoulboundStored(Player player) {
        player.sendMessage(MiniMessage.miniMessage().deserialize("<red>Your mace is soulbound and cannot be stored."));
    }

    private void returnMaceToOnlineOwner(ItemStack item) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (plugin.itemFactory().isOwnedBy(item, player.getUniqueId())) {
                player.getInventory().addItem(item.clone());
                return;
            }
        }
    }

    private record DeathMace(int slot, ItemStack item) { }
    private record KillPair(UUID killer, UUID victim) { }
    private record TeamKill(UUID killer, boolean ownedMaceAtKill) { }
    private record LastAttacker(Player player, long time, boolean ownedMaceAtHit, ItemStack itemAtHit) { }
}
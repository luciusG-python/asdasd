package com.kodari.maceprogression;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/** Administrative and player-facing mace commands. */
public final class MaceCommand implements CommandExecutor, TabCompleter {
    private final MaceProgressionPlugin plugin;

    public MaceCommand(MaceProgressionPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("gui")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(plugin.getConfig().getString("mace_encyclopedia.console_message", "This command can only be used by a player."));
                return true;
            }
            if (!player.hasPermission("maceprogression.gui")) {
                player.sendMessage(MiniMessage.miniMessage().deserialize(
                        plugin.getConfig().getString("mace_encyclopedia.permission_message", "<red>You do not have permission.")));
                return true;
            }
            plugin.maceEncyclopedia().open(player);
            return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("info")) {
            if (!(sender instanceof Player player)) return true;
            PlayerProgress data = plugin.playerData().get(player.getUniqueId());
            int required = plugin.requiredKills(data.getTier());
            String progress = required == 0 ? "max" : data.getKillsTowardNextTier() + "/" + required;
            plugin.send(player, "info", Map.of("player", player.getName(), "tier", data.getTier().displayName(),
                    "kills", Integer.toString(data.getTotalKills()), "progress", progress));
            return true;
        }
        if (args[0].equalsIgnoreCase("top")) {
            plugin.playerData().all().entrySet().stream()
                    .sorted(Map.Entry.<java.util.UUID, PlayerProgress>comparingByValue(Comparator.comparingInt(PlayerProgress::getTotalKills)).reversed())
                    .limit(10).forEach(entry -> sender.sendMessage(MiniMessage.miniMessage().deserialize("<gold>" + Bukkit.getOfflinePlayer(entry.getKey()).getName()
                            + " <gray>- <white>" + entry.getValue().getTotalKills() + " kills, " + entry.getValue().getTier().displayName())));
            return true;
        }
        if (!sender.hasPermission("maceprogression.admin")) {
            sender.sendMessage(MiniMessage.miniMessage().deserialize(plugin.getConfig().getString("messages.prefix", "") + plugin.message("no_permission")));
            return true;
        }
        if (args[0].equalsIgnoreCase("debug") && args.length >= 2) {
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) return playerNotFound(sender);
            PlayerProgress data = plugin.playerData().get(target.getUniqueId());
            int required = plugin.requiredKills(data.getTier());
            int progress = required == 0 ? 0 : Math.min(required, Math.max(0, data.getKillsTowardNextTier()));
            String next = required == 0 ? "Max" : data.getTier().next().displayName();
            var held = target.getInventory().getItemInMainHand();
            boolean validHeldMace = plugin.itemFactory().isOwnedBy(held, target.getUniqueId())
                    && plugin.itemFactory().tierOf(held) == data.getTier();
            sender.sendMessage(MiniMessage.miniMessage().deserialize("<gold>Mace debug: <white>" + target.getName()
                    + " <gray>| Tier: <white>" + data.getTier().displayName()
                    + " <gray>| Total kills: <white>" + data.getTotalKills()));
            sender.sendMessage(MiniMessage.miniMessage().deserialize("<gray>Progress: <white>" + progress + "/"
                    + (required == 0 ? "max" : required) + " <gray>| Next step: <white>" + next
                    + " <gray>| Required kills: <white>" + required
                    + " <gray>| Valid main-hand mace owned by player: " + (validHeldMace ? "<green>yes" : "<red>no")));
            return true;
        }
        if (args[0].equalsIgnoreCase("addkill") && args.length >= 2) {
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) return playerNotFound(sender);
            int amount = 1;
            if (args.length >= 3) {
                try {
                    amount = Integer.parseInt(args[2]);
                } catch (NumberFormatException exception) {
                    sender.sendMessage(MiniMessage.miniMessage().deserialize("<red>Amount must be a positive whole number."));
                    return true;
                }
            }
            if (amount < 1) {
                sender.sendMessage(MiniMessage.miniMessage().deserialize("<red>Amount must be a positive whole number."));
                return true;
            }
            for (int count = 0; count < amount; count++) plugin.listener().recordKill(target);
            sender.sendMessage(MiniMessage.miniMessage().deserialize("<green>Added " + amount + " kill"
                    + (amount == 1 ? "" : "s") + " to " + target.getName() + "."));
            return true;
        }
        if (args[0].equalsIgnoreCase("reload")) {
            plugin.reloadConfig();
            for (Player player : Bukkit.getOnlinePlayers()) {
                plugin.locatorBar().apply(player, plugin.playerData().get(player.getUniqueId()).getTier(), false);
                plugin.refreshMace(player);
            }
            sender.sendMessage(MiniMessage.miniMessage().deserialize(plugin.getConfig().getString("messages.prefix", "") + plugin.message("reloaded")));
            return true;
        }
        if (args[0].equalsIgnoreCase("reset") && args.length >= 2) {
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) return playerNotFound(sender);
            PlayerProgress data = plugin.playerData().get(target.getUniqueId());
            data.setTier(MaceTier.DEFAULT);
            data.setTotalKills(0);
            data.setKillsTowardNextTier(0);
            plugin.replaceMace(target, MaceTier.DEFAULT);
            plugin.locatorBar().apply(target, MaceTier.DEFAULT, true);
            plugin.playerData().save();
            sender.sendMessage(MiniMessage.miniMessage().deserialize(plugin.getConfig().getString("messages.prefix", "")
                    + plugin.message("reset").replace("<player>", target.getName())));
            return true;
        }
        if ((args[0].equalsIgnoreCase("set") || args[0].equalsIgnoreCase("give")) && args.length >= 3) {
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) return playerNotFound(sender);
            MaceTier tier = MaceTier.parse(args[2]);
            if (tier == null) {
                sender.sendMessage(MiniMessage.miniMessage().deserialize(plugin.getConfig().getString("messages.prefix", "") + plugin.message("invalid_tier")));
                return true;
            }
            PlayerProgress data = plugin.playerData().get(target.getUniqueId());
            data.setTier(tier);
            data.setKillsTowardNextTier(0);
            plugin.replaceMace(target, tier);
            plugin.locatorBar().apply(target, tier, true);
            plugin.playerData().save();
            sender.sendMessage(MiniMessage.miniMessage().deserialize(plugin.getConfig().getString("messages.prefix", "")
                    + plugin.message("set").replace("<player>", target.getName()).replace("<tier>", tier.displayName())));
            return true;
        }
        sender.sendMessage("/mace <info|top|give|set|reset|reload|debug|addkill>");
        return true;
    }

    private boolean playerNotFound(CommandSender sender) {
        sender.sendMessage(MiniMessage.miniMessage().deserialize(plugin.getConfig().getString("messages.prefix", "") + plugin.message("player_not_found")));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return startsWith(List.of("info", "top", "gui", "give", "set", "reset", "reload", "debug", "addkill"), args[0]);
        if (args.length == 2 && List.of("give", "set", "reset", "debug", "addkill").contains(args[0].toLowerCase(java.util.Locale.ROOT))) {
            return startsWith(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[1]);
        }
        if (args.length == 3 && List.of("give", "set").contains(args[0].toLowerCase(java.util.Locale.ROOT))) {
            return startsWith(java.util.Arrays.stream(MaceTier.values()).map(Enum::name).toList(), args[2]);
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("addkill")) return List.of("1", "5", "10");
        return List.of();
    }

    private List<String> startsWith(List<String> choices, String prefix) {
        List<String> matches = new ArrayList<>();
        for (String choice : choices) if (choice.regionMatches(true, 0, prefix, 0, prefix.length())) matches.add(choice);
        return matches;
    }
}
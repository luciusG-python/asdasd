package com.kodari.maceprogression;

import org.bukkit.entity.Player;

public interface Ability {
    MaceTier tier();
    String key();
    String name();
    String trigger();
    int cooldownSeconds();
    boolean execute(Player player);
}
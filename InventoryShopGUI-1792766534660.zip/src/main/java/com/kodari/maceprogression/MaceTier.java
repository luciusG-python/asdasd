package com.kodari.maceprogression;

import java.util.Locale;

/** Tier definitions and progression order for plugin maces. */
public enum MaceTier {
    DEFAULT("Default", null),
    WOODEN("Wooden", "default_to_wooden"),
    STONE("Stone", "wooden_to_stone"),
    COPPER("Copper", "stone_to_copper"),
    GOLD("Gold", "copper_to_gold"),
    IRON("Iron", "gold_to_iron"),
    DIAMOND("Diamond", "iron_to_diamond"),
    NETHERITE("Netherite", "diamond_to_netherite"),
    RAINBOW("Rainbow", null);

    private final String displayName;
    private final String requirementKey;

    MaceTier(String displayName, String requirementKey) {
        this.displayName = displayName;
        this.requirementKey = requirementKey;
    }

    public String displayName() {
        return displayName;
    }

    public String key() {
        return name().toLowerCase(Locale.ROOT);
    }

    public MaceTier next() {
        int next = ordinal() + 1;
        return next < values().length ? values()[next] : null;
    }

    public boolean isKillTier() {
        return this.ordinal() <= NETHERITE.ordinal();
    }

    public String requirementKey() {
        return requirementKey;
    }

    public static MaceTier parse(String value) {
        if (value == null) return null;
        try {
            return valueOf(value.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException exception) {
            return null;
        }
    }
}
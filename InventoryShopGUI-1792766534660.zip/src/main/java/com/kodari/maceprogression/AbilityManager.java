package com.kodari.maceprogression;

import com.cryptomorin.xseries.XAttribute;
import com.cryptomorin.xseries.XPotion;
import com.cryptomorin.xseries.XSound;
import com.cryptomorin.xseries.particles.XParticle;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.TileState;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public final class AbilityManager implements Listener {
    private final MaceProgressionPlugin plugin;
    private final CooldownManager cooldowns;
    private final Map<MaceTier, Map<String, Ability>> abilities = new EnumMap<>(MaceTier.class);
    private final Map<java.util.UUID, Long> fallGrace = new HashMap<>();
    private final Map<UUID, BukkitTask> landingTasks = new HashMap<>();
    private final Map<UUID, BukkitTask> earthquakeTasks = new HashMap<>();
    private final Map<UUID, List<BlockDisplay>> earthquakeDisplays = new HashMap<>();
    private final Map<UUID, Set<BukkitTask>> abilityVisualTasks = new HashMap<>();
    private final Map<UUID, DashRun> dashRuns = new HashMap<>();

    public AbilityManager(MaceProgressionPlugin plugin) {
        this.plugin = plugin;
        this.cooldowns = new CooldownManager(plugin);
        add(MaceTier.WOODEN, "dash", "primary");
        add(MaceTier.STONE, "leap", "primary");
        add(MaceTier.COPPER, "lightning_dash", "primary");
        add(MaceTier.GOLD, "sky_leap", "primary");
        add(MaceTier.GOLD, "golden_surge", "secondary");
        add(MaceTier.IRON, "ground_slam", "primary");
        add(MaceTier.IRON, "iron_dash", "secondary");
        add(MaceTier.DIAMOND, "mega_jump", "primary");
        add(MaceTier.DIAMOND, "wither_strike", "secondary");
        add(MaceTier.NETHERITE, "inferno_smash", "primary");
        add(MaceTier.NETHERITE, "blaze_dash", "secondary");
        add(MaceTier.RAINBOW, "rainbow_burst", "primary");
        add(MaceTier.RAINBOW, "rainbow_leap", "secondary");
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND
                || (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK)) return;
        Player player = event.getPlayer();
        ItemStack held = player.getInventory().getItemInMainHand();
        if (!plugin.itemFactory().isOwnedBy(held, player.getUniqueId())) return;
        MaceTier tier = plugin.itemFactory().tierOf(held);
        if (tier == null) return;
        String trigger = player.isSneaking() ? "secondary" : "primary";
        Ability ability = abilities.getOrDefault(tier, Map.of()).get(trigger);
        if (ability == null) return;
        String cooldownId = tier.key() + "." + ability.key();
        if (cooldowns.remainingSeconds(player.getUniqueId(), cooldownId) > 0) {
            cooldowns.showRemaining(player, ability.name(), cooldownId);
            return;
        }
        if (ability.execute(player)) {
            event.setCancelled(true);
            cooldowns.start(player, ability.name(), cooldownId, ability.cooldownSeconds());
        }
    }

    @EventHandler
    public void onMaceHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        ItemStack held = player.getInventory().getItemInMainHand();
        if (!plugin.itemFactory().isOwnedBy(held, player.getUniqueId())) return;
        MaceTier tier = plugin.itemFactory().tierOf(held);
        if (tier == null || !(event.getEntity() instanceof LivingEntity target)) return;

        switch (tier) {
            case WOODEN -> {
                if (!canAffect(player, target)) return;
                double strength = setting(tier, "passive", "knockback", 0.25);
                Vector push = target.getLocation().toVector().subtract(player.getLocation().toVector());
                if (push.lengthSquared() > 0) target.setVelocity(target.getVelocity().add(push.normalize().multiply(strength)));
            }
            case STONE -> applyEffect(player, target, "SLOWNESS", settingInt(tier, "passive", "duration", 3),
                    settingInt(tier, "passive", "amplifier", 1));
            case COPPER -> {
                double chance = setting(tier, "passive", "chance", 0.2);
                if (chance > 1) chance /= 100.0;
                if (ThreadLocalRandom.current().nextDouble() < chance) {
                    applyEffect(player, target, "WEAKNESS", settingInt(tier, "passive", "duration", 3),
                            settingInt(tier, "passive", "amplifier", 0));
                }
            }
            case RAINBOW -> {
                List<String> effects = plugin.getConfig().getStringList("abilities.rainbow.passive.effects");
                if (!effects.isEmpty()) {
                    String effect = effects.get(ThreadLocalRandom.current().nextInt(effects.size()));
                    applyEffect(player, player, effect, settingInt(tier, "passive", "duration", 5),
                            settingInt(tier, "passive", "amplifier", 0));
                }
            }
            default -> { }
        }
    }

    @EventHandler
    public void onFallDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player) || event.getCause() != EntityDamageEvent.DamageCause.FALL) return;
        if (plugin.itemFactory().isOwnedBy(player.getInventory().getItemInMainHand(), player.getUniqueId())
                && plugin.itemFactory().tierOf(player.getInventory().getItemInMainHand()) == MaceTier.RAINBOW) {
            event.setCancelled(true);
            return;
        }
        Long until = fallGrace.get(player.getUniqueId());
        if (until == null) return;
        if (until >= System.currentTimeMillis()) event.setCancelled(true);
        else fallGrace.remove(player.getUniqueId());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID playerId = event.getPlayer().getUniqueId();
        cooldowns.clear(playerId);
        fallGrace.remove(playerId);
        clearLeapEffects(playerId);
        clearAbilityVisuals(playerId);
        cancelDash(playerId);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        clearPlayerEffects(event.getEntity());
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        clearPlayerEffects(event.getPlayer());
    }

    private void clearPlayerEffects(Player player) {
        UUID playerId = player.getUniqueId();
        fallGrace.remove(playerId);
        clearLeapEffects(playerId);
        clearAbilityVisuals(playerId);
        cancelDash(playerId);
    }

    public void shutdown() {
        cooldowns.shutdown();
        fallGrace.clear();
        for (UUID playerId : new HashSet<>(landingTasks.keySet())) clearLeapEffects(playerId);
        for (UUID playerId : new HashSet<>(earthquakeTasks.keySet())) clearEarthquake(playerId);
        for (UUID playerId : new HashSet<>(abilityVisualTasks.keySet())) clearAbilityVisuals(playerId);
        for (UUID playerId : new HashSet<>(dashRuns.keySet())) cancelDash(playerId);
        for (List<BlockDisplay> displays : earthquakeDisplays.values()) {
            for (BlockDisplay display : displays) if (display.isValid()) display.remove();
        }
        earthquakeDisplays.clear();
    }

    private void add(MaceTier tier, String abilityKey, String trigger) {
        Ability ability = new ConfiguredAbility(tier, abilityKey, trigger);
        abilities.computeIfAbsent(tier, ignored -> new HashMap<>()).put(trigger, ability);
    }

    public List<Ability> abilitiesFor(MaceTier tier) {
        return List.copyOf(abilities.getOrDefault(tier, Map.of()).values());
    }

    private boolean execute(Ability ability, Player player) {
        MaceTier tier = ability.tier();
        String key = ability.key();
        return switch (key) {
            case "dash" -> dash(player, ability, false);
            case "lightning_dash" -> dash(player, ability, true);
            case "iron_dash" -> dash(player, ability, false);
            case "blaze_dash" -> dash(player, ability, false);
            case "leap", "sky_leap", "mega_jump" -> leap(player, ability, 0);
            case "rainbow_leap" -> leap(player, ability, setting(tier, key, "distance", 50));
            case "golden_surge" -> goldenSurge(player, ability);
            case "ground_slam" -> groundSlam(player, ability, false);
            case "inferno_smash" -> groundSlam(player, ability, true);
            case "wither_strike" -> witherStrike(player, ability);
            case "rainbow_burst" -> rainbowBurst(player, ability);
            default -> false;
        };
    }

    private boolean leap(Player player, Ability ability, double forwardDistance) {
        double velocity = setting(ability.tier(), ability.key(), "velocity", 1.5);
        Vector current = player.getVelocity();
        if (forwardDistance > 0) {
            Vector direction = horizontalDirection(player);
            current.add(direction.multiply(forwardDistance > 0 ? setting(ability.tier(), ability.key(), "horizontal_velocity", 1.1) : 0));
        }
        current.setY(velocity);
        player.setVelocity(current);
        grantFallGrace(player);
        playAbilityVisual(player, ability.key(), player.getLocation());
        startLandingMonitor(player, ability);
        return true;
    }

    private void startLandingMonitor(Player player, Ability ability) {
        UUID playerId = player.getUniqueId();
        clearLeapEffects(playerId);
        World launchWorld = player.getWorld();
        int timeout = Math.max(10, plugin.getConfig().getInt("abilities.earthquake_landing_timeout_ticks", 100));
        BukkitTask task = new org.bukkit.scheduler.BukkitRunnable() {
            private int ticks;
            private boolean airborne;

            @Override
            public void run() {
                ticks++;
                if (!player.isOnline() || !player.isValid() || player.isDead() || player.getWorld() != launchWorld) {
                    landingTasks.remove(playerId);
                    cancel();
                    return;
                }
                if (!player.isOnGround()) airborne = true;
                else if (airborne || ticks >= 8) {
                    landingTasks.remove(playerId);
                    cancel();
                    createLandingShockwave(player, ability);
                    return;
                }
                if (ticks >= timeout) {
                    landingTasks.remove(playerId);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        landingTasks.put(playerId, task);
    }

    private void createLandingShockwave(Player player, Ability ability) {
        UUID playerId = player.getUniqueId();
        clearEarthquake(playerId);
        Location center = player.getLocation();
        World world = center.getWorld();
        double radius = Math.max(1.0, setting(ability.tier(), ability.key(), "shockwave_radius",
                setting(ability.tier(), ability.key(), "earthquake_radius", 3.0)));
        int maxBlocks = Math.max(1, settingInt(ability.tier(), ability.key(), "shockwave_max_blocks", 100));
        double waveSpeed = Math.max(0.1, setting(ability.tier(), ability.key(), "shockwave_wave_speed_ticks_per_block", 1.0));
        double launchHeight = Math.max(0.1, setting(ability.tier(), ability.key(), "shockwave_launch_height", 2.0));
        int settleTicks = Math.max(4, settingInt(ability.tier(), ability.key(), "shockwave_settle_ticks", 30));
        List<ShockwaveBlock> blocks = new ArrayList<>();
        int centerX = center.getBlockX();
        int groundY = center.getBlockY() - 1;
        int centerZ = center.getBlockZ();

        for (int x = (int) -Math.ceil(radius); x <= Math.ceil(radius); x++) {
            for (int z = (int) -Math.ceil(radius); z <= Math.ceil(radius); z++) {
                double distance = Math.sqrt(x * x + z * z);
                if (distance > radius || !world.isChunkLoaded((centerX + x) >> 4, (centerZ + z) >> 4)) continue;
                Block ground = world.getBlockAt(centerX + x, groundY, centerZ + z);
                if (!ground.getType().isSolid() || ground.getType().isAir() || ground.isLiquid()
                        || ground.getType().getHardness() < 0 || ground.getState() instanceof TileState) continue;
                ShockwaveMotion motion = ShockwaveMotion.values()[ThreadLocalRandom.current().nextInt(ShockwaveMotion.values().length)];
                double angle = ThreadLocalRandom.current().nextDouble(Math.PI * 2);
                blocks.add(new ShockwaveBlock(ground.getLocation(), ground.getBlockData(), distance, motion, angle,
                        Math.max(0.05, launchHeight * (0.75 + ThreadLocalRandom.current().nextDouble() * 0.5))));
            }
        }
        blocks.sort(java.util.Comparator.comparingDouble(ShockwaveBlock::distance));
        if (blocks.size() > maxBlocks) blocks = new ArrayList<>(blocks.subList(0, maxBlocks));
        List<ShockwaveBlock> affectedBlocks = blocks;

        String rumbleName = plugin.getConfig().getString("abilities." + ability.tier().key() + "." + ability.key()
                + ".shockwave_rumble_sound", "ENTITY_GENERIC_EXPLODE");
        String blockSoundName = plugin.getConfig().getString("abilities." + ability.tier().key() + "." + ability.key()
                + ".shockwave_block_sound", "BLOCK_STONE_BREAK");
        float rumbleVolume = (float) setting(ability.tier(), ability.key(), "shockwave_rumble_volume", 0.45);
        float rumblePitch = (float) setting(ability.tier(), ability.key(), "shockwave_rumble_pitch", 0.65);
        XSound.matchXSound(rumbleName).ifPresent(sound -> world.playSound(center, sound.get(), rumbleVolume, rumblePitch));
        XParticle.of("CLOUD").ifPresent(particle -> world.spawnParticle(particle.get(), center.clone().add(0, 0.1, 0),
                Math.min(40, Math.max(12, affectedBlocks.size() / 2)), radius / 3, 0.08, radius / 3, 0.015));

        List<BlockDisplay> displays = new ArrayList<>();
        if (affectedBlocks.isEmpty()) return;
        earthquakeDisplays.put(playerId, displays);
        BukkitTask task = new org.bukkit.scheduler.BukkitRunnable() {
            private int tick;
            private int soundedBlocks;

            @Override
            public void run() {
                if (!player.isOnline() || !player.isValid() || player.isDead() || player.getWorld() != world) {
                    clearEarthquake(playerId);
                    cancel();
                    return;
                }
                tick++;
                boolean complete = true;
                for (ShockwaveBlock block : affectedBlocks) {
                    int delay = (int) Math.round(block.distance() * waveSpeed);
                    int age = tick - delay;
                    if (age < 0) {
                        complete = false;
                        continue;
                    }
                    if (age >= settleTicks) continue;
                    complete = false;
                    BlockDisplay display = block.display();
                    if (display == null || !display.isValid()) {
                        Location origin = block.origin();
                        display = world.spawn(origin, BlockDisplay.class, entity -> {
                            entity.setBlock(block.data());
                            entity.setPersistent(false);
                            entity.setInvulnerable(true);
                        });
                        block.setDisplay(display);
                        displays.add(display);
                        XParticle.of("BLOCK").ifPresent(particle -> world.spawnParticle(particle.get(),
                                origin.clone().add(0.5, 0.5, 0.5), 8, 0.22, 0.22, 0.22, 0.08, block.data()));
                        if (soundedBlocks++ % 4 == 0) {
                            XSound.matchXSound(blockSoundName).ifPresent(sound -> world.playSound(origin, sound.get(), 0.35f, 0.85f));
                        }
                    }
                    double progress = Math.min(1.0, (double) age / settleTicks);
                    double eased = Math.sin(Math.PI * progress);
                    Location animated = block.origin().clone();
                    switch (block.motion()) {
                        case SINK -> animated.add(0, -eased, 0);
                        case RISE -> animated.add(0, eased, 0);
                        case LAUNCH -> animated.add(0, block.height() * 4 * progress * (1 - progress), 0);
                        case SHAKE -> animated.add(Math.cos(block.angle()) * Math.sin(progress * Math.PI * 12) * 0.12 * (1 - progress),
                                Math.sin(progress * Math.PI * 12) * 0.06 * (1 - progress),
                                Math.sin(block.angle()) * Math.sin(progress * Math.PI * 12) * 0.12 * (1 - progress));
                    }
                    if (display.isValid()) display.teleport(animated);
                }
                if (complete) {
                    clearEarthquake(playerId);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        earthquakeTasks.put(playerId, task);
    }

    private void createEarthquake(Player player, Ability ability) {
        UUID playerId = player.getUniqueId();
        clearEarthquake(playerId);
        Location center = player.getLocation();
        World world = center.getWorld();
        double radius = Math.max(1.0, setting(ability.tier(), ability.key(), "earthquake_radius", 2.0));
        double intensity = Math.max(0.1, setting(ability.tier(), ability.key(), "earthquake_intensity", 0.5));
        int duration = Math.max(2, settingInt(ability.tier(), ability.key(), "earthquake_duration_ticks", 14));
        int maxBlocks = Math.max(1, settingInt(ability.tier(), ability.key(), "earthquake_max_blocks", 20));
        int centerX = center.getBlockX();
        int groundY = center.getBlockY() - 1;
        int centerZ = center.getBlockZ();
        BlockData stone = Bukkit.createBlockData("minecraft:stone");
        List<RisingBlock> risingBlocks = new ArrayList<>();

        for (int x = (int) -Math.ceil(radius); x <= Math.ceil(radius) && risingBlocks.size() < maxBlocks; x++) {
            for (int z = (int) -Math.ceil(radius); z <= Math.ceil(radius) && risingBlocks.size() < maxBlocks; z++) {
                if (x * x + z * z > radius * radius) continue;
                Block ground = world.getBlockAt(centerX + x, groundY, centerZ + z);
                if (!ground.getType().isSolid()) continue;
                Location origin = ground.getLocation().add(0, 1, 0);
                BlockDisplay display = world.spawn(origin, BlockDisplay.class, blockDisplay -> {
                    blockDisplay.setBlock(stone);
                    blockDisplay.setPersistent(false);
                    blockDisplay.setInvulnerable(true);
                });
                risingBlocks.add(new RisingBlock(display, origin, intensity * (0.55 + ThreadLocalRandom.current().nextDouble() * 0.45)));
            }
        }

        int particlePoints = Math.max(16, (int) Math.round(radius * 8));
        XParticle.of("BLOCK").ifPresent(particle -> {
            for (int index = 0; index < particlePoints; index++) {
                double angle = Math.PI * 2 * index / particlePoints;
                Location point = center.clone().add(Math.cos(angle) * radius, 0.1, Math.sin(angle) * radius);
                world.spawnParticle(particle.get(), point, 2, 0.08, 0.04, 0.08, stone);
            }
        });
        XParticle.of("CLOUD").ifPresent(particle -> world.spawnParticle(particle.get(), center.clone().add(0, 0.15, 0),
                particlePoints / 2, radius / 3, 0.12, radius / 3, 0.02));
        XSound.matchXSound("ENTITY_GENERIC_EXPLODE").ifPresent(sound ->
                world.playSound(center, sound.get(), (float) Math.min(1.5, 0.7 + intensity * 0.35), 0.65f));

        if (risingBlocks.isEmpty()) return;
        earthquakeDisplays.put(playerId, risingBlocks.stream().map(RisingBlock::display).toList());
        BukkitTask task = new org.bukkit.scheduler.BukkitRunnable() {
            private int tick;

            @Override
            public void run() {
                tick++;
                double progress = (double) tick / duration;
                for (RisingBlock rising : risingBlocks) {
                    if (rising.display().isValid()) {
                        rising.display().teleport(rising.origin().clone().add(0, rising.height() * Math.sin(Math.PI * progress), 0));
                    }
                }
                if (tick >= duration) {
                    clearEarthquake(playerId);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        earthquakeTasks.put(playerId, task);
    }

    private void clearLeapEffects(UUID playerId) {
        BukkitTask landingTask = landingTasks.remove(playerId);
        if (landingTask != null) landingTask.cancel();
        clearEarthquake(playerId);
    }

    private void clearEarthquake(UUID playerId) {
        BukkitTask task = earthquakeTasks.remove(playerId);
        if (task != null) task.cancel();
        List<BlockDisplay> displays = earthquakeDisplays.remove(playerId);
        if (displays != null) {
            for (BlockDisplay display : displays) if (display.isValid()) display.remove();
        }
    }

    private boolean goldenSurge(Player player, Ability ability) {
        int duration = settingInt(ability.tier(), ability.key(), "duration", 8);
        applyEffect(player, player, "SPEED", duration, settingInt(ability.tier(), ability.key(), "speed_amplifier", 1));
        applyEffect(player, player, "ABSORPTION", duration, settingInt(ability.tier(), ability.key(), "absorption_amplifier", 0));
        playAbilityVisual(player, ability.key(), player.getLocation());
        return true;
    }

    private boolean dash(Player player, Ability ability, boolean lightning) {
        UUID playerId = player.getUniqueId();
        if (dashRuns.containsKey(playerId)) return false;
        double distance = setting(ability.tier(), ability.key(), "distance", 8);
        if (distance <= 0) return false;
        DashRun run = new DashRun(player, ability, lightning, Math.max(0.05,
                setting(ability.tier(), ability.key(), "speed", setting(ability.tier(), ability.key(), "velocity", 0.8))));
        dashRuns.put(playerId, run);
        run.runTaskTimer(plugin, 1L, 1L);
        return true;
    }

    private void cancelDash(UUID playerId) {
        DashRun run = dashRuns.remove(playerId);
        if (run != null) run.stop(false, false);
    }

    private final class DashRun extends org.bukkit.scheduler.BukkitRunnable {
        private final Player player;
        private final Ability ability;
        private final UUID playerId;
        private final World world;
        private final Location start;
        private final Vector direction;
        private final Vector side;
        private final double maxDistance;
        private final double speed;
        private final double damage;
        private final double knockback;
        private final int windupTicks;
        private final int durationTicks;
        private final boolean lightning;
        private final boolean previousSwimming;
        private final Set<UUID> hitEntities = new HashSet<>();
        private int ticks;
        private int activeTicks;
        private boolean ended;
        private boolean finishAfterMove;

        private DashRun(Player player, Ability ability, boolean lightning, double speed) {
            this.player = player;
            this.ability = ability;
            this.playerId = player.getUniqueId();
            this.world = player.getWorld();
            this.start = player.getLocation().clone();
            Vector lookDirection = player.getEyeLocation().getDirection().normalize();
            this.direction = lookDirection.lengthSquared() == 0 ? horizontalDirection(player) : lookDirection;
            this.side = new Vector(-direction.getZ(), 0, direction.getX());
            if (side.lengthSquared() == 0) side.setX(1);
            else side.normalize();
            this.maxDistance = setting(ability.tier(), ability.key(), "distance", 8);
            this.speed = speed;
            this.damage = Math.max(0, setting(ability.tier(), ability.key(), "damage", 0));
            this.knockback = Math.max(0, setting(ability.tier(), ability.key(), "knockback", 0.7));
            this.windupTicks = Math.max(0, settingInt(ability.tier(), ability.key(), "windup_ticks", 5));
            this.durationTicks = Math.max(1, settingInt(ability.tier(), ability.key(), "dash_duration_ticks", 10));
            this.lightning = lightning;
            this.previousSwimming = player.isSwimming();
            player.setSwimming(true);
            playDashSound("windup_sound", "BLOCK_BEACON_ACTIVATE", start, 0.6f, 0.8f);
            XParticle.of("CLOUD").ifPresent(particle -> world.spawnParticle(particle.get(), start.clone().add(0, 0.8, 0),
                    18, 0.35, 0.25, 0.35, 0.04));
        }

        @Override
        public void run() {
            if (!player.isOnline() || !player.isValid() || player.isDead() || player.getWorld() != world) {
                stop(false, false);
                return;
            }
            if (finishAfterMove) {
                stop(true, false);
                return;
            }
            ticks++;
            if (ticks <= windupTicks) return;
            if (activeTicks == 0) playDashSound("launch_sound", "ENTITY_PLAYER_ATTACK_SWEEP", player.getLocation(), 0.8f, 1.2f);
            if (activeTicks >= durationTicks) {
                stop(true, false);
                return;
            }

            Location current = player.getLocation();
            double traveled = Math.max(0, current.toVector().subtract(start.toVector()).dot(direction));
            double remaining = maxDistance - traveled;
            if (remaining <= 0.05) {
                stop(true, false);
                return;
            }
            double requestedStep = Math.min(speed, remaining);
            double safeStep = collisionSafeStep(current, requestedStep);
            if (safeStep < 0.05) {
                Location impact = current.clone().add(direction.clone().multiply(0.2));
                showImpact(impact);
                player.setVelocity(new Vector(0, player.getVelocity().getY(), 0));
                stop(true, false);
                return;
            }

            for (double along = 0; along <= safeStep; along += 0.2) {
                Location point = current.clone().add(direction.clone().multiply(along)).add(0, 1.0, 0);
                XParticle.of("CRIT").ifPresent(particle -> world.spawnParticle(particle.get(), point, 2, 0.03, 0.03, 0.03, 0.01));
                XParticle.of("END_ROD").ifPresent(particle -> world.spawnParticle(particle.get(), point, 1, 0.02, 0.02, 0.02, 0.0));
                if (ability.key().equals("blaze_dash")) {
                    XParticle.of("FLAME").ifPresent(particle -> world.spawnParticle(particle.get(), point, 2, 0.08, 0.08, 0.08, 0.01));
                }
                for (Entity entity : world.getNearbyEntities(point, 0.34, 0.42, 0.34)) {
                    if (!(entity instanceof LivingEntity target) || !hitEntities.add(target.getUniqueId()) || !canAffect(player, target)) continue;
                    if (damage > 0) target.damage(damage, player);
                    Vector push = direction.clone().multiply(knockback);
                    push.setY(push.getY() + 0.15);
                    target.setVelocity(target.getVelocity().add(push));
                    showImpact(target.getLocation());
                }
            }
            Location afterimage = current.clone().subtract(direction.clone().multiply(0.45)).add(0, 0.9, 0);
            XParticle.of("CLOUD").ifPresent(particle -> world.spawnParticle(particle.get(), afterimage, 4, 0.12, 0.16, 0.12, 0.01));
            if (activeTicks % 2 == 0) player.swingMainHand();
            activeTicks++;

            if (safeStep < requestedStep - 0.01) {
                Location safeDestination = current.clone().add(direction.clone().multiply(safeStep));
                player.teleport(safeDestination);
                showImpact(safeDestination.clone().add(0, 1, 0));
                stop(true, false);
                return;
            }
            player.setVelocity(direction.clone().multiply(safeStep));
            if (activeTicks >= durationTicks || traveled + safeStep >= maxDistance) finishAfterMove = true;
        }

        private double collisionSafeStep(Location current, double requestedStep) {
            double safeStep = requestedStep;
            for (double height : new double[]{0.15, 0.9, 1.6}) {
                for (double lateral : new double[]{-0.24, 0.0, 0.24}) {
                    Location rayOrigin = current.clone().add(0, height, 0).add(side.clone().multiply(lateral));
                    RayTraceResult hit = world.rayTraceBlocks(rayOrigin, direction, requestedStep + 0.3,
                            org.bukkit.FluidCollisionMode.NEVER, false);
                    if (hit == null) continue;
                    double hitDistance = rayOrigin.distance(hit.getHitPosition().toLocation(world));
                    safeStep = Math.min(safeStep, Math.max(0, hitDistance - 0.28));
                }
            }
            return safeStep;
        }

        private void playDashSound(String field, String fallback, Location location, float volume, float pitch) {
            String soundName = plugin.getConfig().getString("abilities." + ability.tier().key() + "." + ability.key()
                    + "." + field, fallback);
            XSound.matchXSound(soundName).ifPresent(sound -> world.playSound(location, sound.get(), volume, pitch));
        }

        private void showImpact(Location location) {
            XParticle.of("CRIT").ifPresent(particle -> world.spawnParticle(particle.get(), location, 12, 0.18, 0.18, 0.18, 0.04));
            XParticle.of("SWEEP_ATTACK").ifPresent(particle -> world.spawnParticle(particle.get(), location, 1, 0.0, 0.0, 0.0, 0.0));
            playDashSound("impact_sound", "ENTITY_PLAYER_ATTACK_CRIT", location, 0.7f, 0.9f);
        }

        private void stop(boolean completed, boolean impact) {
            if (ended) return;
            ended = true;
            dashRuns.remove(playerId, this);
            cancel();
            if (player.isOnline() && player.isValid()) {
                player.setSwimming(previousSwimming);
                Vector currentVelocity = player.getVelocity();
                player.setVelocity(new Vector(0, currentVelocity.getY(), 0));
                if (completed) {
                    grantFallGrace(player);
                    if (lightning) world.strikeLightningEffect(player.getLocation());
                    if (impact) showImpact(player.getLocation());
                }
            }
        }
    }

    private boolean groundSlam(Player player, Ability ability, boolean inferno) {
        MaceTier tier = ability.tier();
        double radius = setting(tier, ability.key(), "distance", 6);
        double damage = setting(tier, ability.key(), "damage", 5);
        double launch = setting(tier, ability.key(), "velocity", 0.8);
        Location center = player.getLocation();
        World world = player.getWorld();
        createEarthquake(player, ability);
        playAbilityVisual(player, ability.key(), center);
        if (inferno) {
            int duration = settingInt(tier, ability.key(), "duration", 10);
            applyEffect(player, player, "FIRE_RESISTANCE", duration, 0);
            XParticle.of("FLAME").ifPresent(particle -> {
                for (int index = 0; index < 32; index++) {
                    double angle = Math.PI * 2 * index / 32.0;
                    Location point = center.clone().add(Math.cos(angle) * radius, 0.15, Math.sin(angle) * radius);
                    world.spawnParticle(particle.get(), point, 3, 0.15, 0.1, 0.15, 0.02);
                }
            });
        } else {
            XParticle.of("CLOUD").ifPresent(particle -> world.spawnParticle(particle.get(), center, 35, radius / 3, 0.2, radius / 3, 0.08));
        }
        for (Entity entity : world.getNearbyEntities(center, radius, radius, radius)) {
            if (!(entity instanceof LivingEntity target) || !canAffect(player, target)) continue;
            if (inferno && center.distance(target.getLocation()) > radius) continue;
            target.damage(damage, player);
            if (inferno) target.setFireTicks(Math.max(target.getFireTicks(), settingInt(tier, ability.key(), "duration", 10) * 20));
            Vector away = target.getLocation().toVector().subtract(center.toVector());
            if (away.lengthSquared() > 0) away.normalize().multiply(0.7);
            away.setY(launch);
            target.setVelocity(away);
        }
        return true;
    }

    private boolean witherStrike(Player player, Ability ability) {
        LivingEntity target = targetedEntity(player, setting(ability.tier(), ability.key(), "distance", 5));
        if (target == null || !canAffect(player, target)) return false;
        double damage = setting(ability.tier(), ability.key(), "damage", 4);
        target.damage(damage, player);
        applyEffect(player, target, "WITHER", settingInt(ability.tier(), ability.key(), "duration", 10),
                settingInt(ability.tier(), ability.key(), "amplifier", 1));
        double maximumHealth = XAttribute.of("max_health")
                .map(attribute -> player.getAttribute(attribute.get()))
                .map(org.bukkit.attribute.AttributeInstance::getValue).orElse(20.0);
        player.setHealth(Math.min(maximumHealth, player.getHealth() + setting(ability.tier(), ability.key(), "lifesteal", 2)));
        playAbilityVisual(player, ability.key(), target.getLocation());
        return true;
    }

    private boolean rainbowBurst(Player player, Ability ability) {
        int duration = settingInt(ability.tier(), ability.key(), "duration", 8);
        applyEffect(player, player, "RESISTANCE", duration, settingInt(ability.tier(), ability.key(), "resistance_amplifier", 1));
        applyEffect(player, player, "REGENERATION", duration, settingInt(ability.tier(), ability.key(), "regeneration_amplifier", 1));
        Location center = player.getLocation();
        double radius = setting(ability.tier(), ability.key(), "distance", 8);
        XParticle.of("END_ROD").ifPresent(particle -> player.getWorld().spawnParticle(particle.get(), center, 50, radius / 3, 0.3, radius / 3, 0.05));
        playAbilityVisual(player, ability.key(), center);
        for (Entity entity : player.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (!(entity instanceof LivingEntity target) || !canAffect(player, target)
                    || center.distance(target.getLocation()) > radius) continue;
            target.damage(setting(ability.tier(), ability.key(), "damage", 6), player);
            Vector away = target.getLocation().toVector().subtract(center.toVector());
            if (away.lengthSquared() > 0) target.setVelocity(away.normalize().multiply(setting(ability.tier(), ability.key(), "velocity", 1.2)).setY(0.6));
        }
        return true;
    }

    private void playAbilityVisual(Player player, String ability, Location location) {
        AbilityVisual visual = switch (ability) {
            case "dash" -> new AbilityVisual("CRIT", "ENTITY_PLAYER_ATTACK_SWEEP", 1.2f);
            case "lightning_dash" -> new AbilityVisual("ELECTRIC_SPARK", "ENTITY_LIGHTNING_BOLT_THUNDER", 1.4f);
            case "iron_dash" -> new AbilityVisual("CLOUD", "BLOCK_IRON_DOOR_OPEN", 0.8f);
            case "blaze_dash" -> new AbilityVisual("SOUL_FIRE_FLAME", "ENTITY_BLAZE_SHOOT", 1.0f);
            case "leap" -> new AbilityVisual("CLOUD", "ENTITY_ENDER_DRAGON_FLAP", 1.4f);
            case "sky_leap" -> new AbilityVisual("END_ROD", "ENTITY_FIREWORK_ROCKET_LAUNCH", 1.0f);
            case "mega_jump" -> new AbilityVisual("CRIT", "ENTITY_PLAYER_ATTACK_KNOCKBACK", 0.8f);
            case "rainbow_leap" -> new AbilityVisual("END_ROD", "ENTITY_FIREWORK_ROCKET_TWINKLE", 1.4f);
            case "golden_surge" -> new AbilityVisual("ENCHANT", "BLOCK_BEACON_POWER_SELECT", 1.2f);
            case "ground_slam" -> new AbilityVisual("BLOCK", "BLOCK_ANVIL_LAND", 0.8f);
            case "inferno_smash" -> new AbilityVisual("FLAME", "ENTITY_BLAZE_HURT", 0.7f);
            case "wither_strike" -> new AbilityVisual("SOUL", "ENTITY_WITHER_HURT", 0.8f);
            case "rainbow_burst" -> new AbilityVisual("TOTEM_OF_UNDYING", "ITEM_TOTEM_USE", 1.2f);
            default -> null;
        };
        if (visual == null) return;
        World world = location.getWorld();
        Location origin = location.clone();
        XSound.matchXSound(visual.sound()).ifPresent(sound -> world.playSound(origin, sound.get(), 0.8f, visual.pitch()));
        XParticle.of(visual.particle()).ifPresent(particle -> {
            UUID playerId = player.getUniqueId();
            BukkitTask[] scheduledTask = new BukkitTask[1];
            BukkitTask task = new org.bukkit.scheduler.BukkitRunnable() {
                private int tick;

                @Override
                public void run() {
                    if (!player.isOnline() || player.getWorld() != world) {
                        finish();
                        return;
                    }
                    tick++;
                    double radius = 0.2 + tick * 0.14;
                    for (int index = 0; index < 8; index++) {
                        double angle = Math.PI * 2 * index / 8.0;
                        Location point = origin.clone().add(Math.cos(angle) * radius, 0.6 + tick * 0.08,
                                Math.sin(angle) * radius);
                        world.spawnParticle(particle.get(), point, 1, 0.01, 0.01, 0.01, 0.0);
                    }
                    if (tick >= 4) finish();
                }

                private void finish() {
                    Set<BukkitTask> tasks = abilityVisualTasks.get(playerId);
                    if (tasks != null) {
                        tasks.remove(scheduledTask[0]);
                        if (tasks.isEmpty()) abilityVisualTasks.remove(playerId);
                    }
                    cancel();
                }
            }.runTaskTimer(plugin, 1L, 1L);
            scheduledTask[0] = task;
            abilityVisualTasks.computeIfAbsent(playerId, ignored -> new HashSet<>()).add(task);
        });
    }

    private void clearAbilityVisuals(UUID playerId) {
        Set<BukkitTask> tasks = abilityVisualTasks.remove(playerId);
        if (tasks != null) for (BukkitTask task : tasks) task.cancel();
    }

    private LivingEntity targetedEntity(Player player, double distance) {
        Vector direction = player.getEyeLocation().getDirection().normalize();
        Location eye = player.getEyeLocation();
        LivingEntity closest = null;
        double closestDistance = distance + 1;
        for (Entity entity : player.getWorld().getNearbyEntities(eye, distance, distance, distance)) {
            if (!(entity instanceof LivingEntity target) || target == player || !player.hasLineOfSight(target)) continue;
            Vector offset = target.getEyeLocation().toVector().subtract(eye.toVector());
            double along = offset.dot(direction);
            if (along < 0 || along > distance || offset.clone().subtract(direction.clone().multiply(along)).length() > 1.3) continue;
            if (along < closestDistance) {
                closest = target;
                closestDistance = along;
            }
        }
        return closest;
    }

    private boolean canAffect(Player player, LivingEntity target) {
        if (target == player || target.isDead()) return false;
        if (!(target instanceof Player other) || plugin.getConfig().getBoolean("abilities.friendly_fire", false)) return true;
        var firstTeam = player.getScoreboard().getEntryTeam(player.getName());
        var secondTeam = other.getScoreboard().getEntryTeam(other.getName());
        return firstTeam == null || secondTeam == null || !firstTeam.equals(secondTeam);
    }

    private void applyEffect(Player source, LivingEntity target, String potion, int seconds, int amplifier) {
        if (!canAffect(source, target) && source != target) return;
        XPotion.matchXPotion(potion).map(effect -> effect.buildPotionEffect(Math.max(1, seconds) * 20, Math.max(0, amplifier)))
                .ifPresent(target::addPotionEffect);
    }

    private Vector horizontalDirection(Player player) {
        Vector direction = player.getLocation().getDirection().setY(0);
        if (direction.lengthSquared() == 0) return new Vector(0, 0, 1);
        return direction.normalize();
    }

    private void grantFallGrace(Player player) {
        int seconds = Math.max(0, plugin.getConfig().getInt("abilities.fall_grace_seconds", 3));
        fallGrace.put(player.getUniqueId(), System.currentTimeMillis() + seconds * 1000L);
    }

    private double setting(MaceTier tier, String ability, String field, double fallback) {
        return plugin.getConfig().getDouble("abilities." + tier.key() + "." + ability + "." + field, fallback);
    }

    private int settingInt(MaceTier tier, String ability, String field, int fallback) {
        return plugin.getConfig().getInt("abilities." + tier.key() + "." + ability + "." + field, fallback);
    }

    private final class ConfiguredAbility implements Ability {
        private final MaceTier tier;
        private final String key;
        private final String trigger;

        private ConfiguredAbility(MaceTier tier, String key, String trigger) {
            this.tier = tier;
            this.key = key;
            this.trigger = trigger;
        }

        @Override public MaceTier tier() { return tier; }
        @Override public String key() { return key; }
        @Override public String name() { return plugin.getConfig().getString("abilities." + tier.key() + "." + key + ".name", humanize(key)); }
        @Override public String trigger() { return trigger; }
        @Override public int cooldownSeconds() { return settingInt(tier, key, "cooldown", 0); }
        @Override public boolean execute(Player player) { return AbilityManager.this.execute(this, player); }
    }

    private String humanize(String key) {
        String value = key.toLowerCase(Locale.ROOT).replace('_', ' ');
        return Character.toUpperCase(value.charAt(0)) + value.substring(1);
    }

    private record RisingBlock(BlockDisplay display, Location origin, double height) { }
    private record AbilityVisual(String particle, String sound, float pitch) { }

    private enum ShockwaveMotion { SINK, RISE, LAUNCH, SHAKE }

    private static final class ShockwaveBlock {
        private final Location origin;
        private final BlockData data;
        private final double distance;
        private final ShockwaveMotion motion;
        private final double angle;
        private final double height;
        private BlockDisplay display;

        private ShockwaveBlock(Location origin, BlockData data, double distance, ShockwaveMotion motion, double angle, double height) {
            this.origin = origin;
            this.data = data;
            this.distance = distance;
            this.motion = motion;
            this.angle = angle;
            this.height = height;
        }

        private Location origin() { return origin; }
        private BlockData data() { return data; }
        private double distance() { return distance; }
        private ShockwaveMotion motion() { return motion; }
        private double angle() { return angle; }
        private double height() { return height; }
        private BlockDisplay display() { return display; }
        private void setDisplay(BlockDisplay display) { this.display = display; }
    }
}
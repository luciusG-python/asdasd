package com.kodari.maceprogression;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Loads and saves player progression independently of online state. */
public final class PlayerDataManager {
    private final JavaPlugin plugin;
    private final File file;
    private final Map<UUID, PlayerProgress> players = new HashMap<>();

    public PlayerDataManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "players.yml");
        load();
    }

    public PlayerProgress get(UUID id) {
        return players.computeIfAbsent(id, ignored -> new PlayerProgress());
    }

    public Map<UUID, PlayerProgress> all() {
        return Map.copyOf(players);
    }

    public void load() {
        players.clear();
        if (!file.exists()) return;
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = yaml.getConfigurationSection("players");
        if (section == null) return;
        boolean repaired = false;
        for (String rawId : section.getKeys(false)) {
            try {
                UUID id = UUID.fromString(rawId);
                String path = "players." + rawId + ".";
                MaceTier tier = MaceTier.parse(yaml.getString(path + "tier"));
                int storedKills = yaml.isInt(path + "total_kills") ? yaml.getInt(path + "total_kills") : 0;
                int storedProgress = yaml.isInt(path + "progress") ? yaml.getInt(path + "progress") : 0;
                if (!yaml.isInt(path + "total_kills") || !yaml.isInt(path + "progress")) repaired = true;
                int totalKills = Math.max(0, storedKills);
                int progress = Math.max(0, storedProgress);
                if (tier == null) {
                    tier = MaceTier.DEFAULT;
                    progress = 0;
                    repaired = true;
                }
                if (totalKills != storedKills || progress != storedProgress) repaired = true;
                if (plugin instanceof MaceProgressionPlugin progressionPlugin) {
                    while (tier.ordinal() < MaceTier.NETHERITE.ordinal()) {
                        int needed = progressionPlugin.requiredKills(tier);
                        if (progress < needed) break;
                        progress -= needed;
                        tier = tier.next();
                        repaired = true;
                    }
                }
                if (tier.ordinal() >= MaceTier.NETHERITE.ordinal() && progress != 0) {
                    progress = 0;
                    repaired = true;
                }
                players.put(id, new PlayerProgress(
                        tier, totalKills, progress));
            } catch (IllegalArgumentException exception) {
                plugin.getLogger().warning("Skipping invalid player UUID in players.yml: " + rawId);
                repaired = true;
            }
        }
        if (repaired) save();
    }

    public void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        players.forEach((id, data) -> {
            String path = "players." + id + ".";
            yaml.set(path + "tier", data.getTier().name());
            yaml.set(path + "total_kills", data.getTotalKills());
            yaml.set(path + "progress", data.getKillsTowardNextTier());
        });
        try {
            plugin.getDataFolder().mkdirs();
            yaml.save(file);
        } catch (IOException exception) {
            plugin.getLogger().severe("Could not save players.yml: " + exception.getMessage());
        }
    }
}
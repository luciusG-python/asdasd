package com.kodari.maceprogression;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/** Plugin bootstrap and shared progression services. */
public final class MaceProgressionPlugin extends JavaPlugin {
    private PlayerDataManager playerData;
    private MaceItemFactory itemFactory;
    private LocatorBarManager locatorBar;
    private MaceListener listener;
    private AbilityManager abilityManager;
    private VillagerManager villagerManager;
    private TeamManager teamManager;
    private MaceSmithZoneManager smithZoneManager;
    private MaceEncyclopedia maceEncyclopedia;
    private NamespacedKey locatorFlagKey;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        String resourcePackUrl = getConfig().getString("resource_pack.url", "");
        if (resourcePackUrl == null || resourcePackUrl.isBlank()) {
            getLogger().warning("resource_pack.url is empty; tier textures will not be sent to players.");
        }
        locatorFlagKey = new NamespacedKey(this, "locator_modified");
        playerData = new PlayerDataManager(this);
        itemFactory = new MaceItemFactory(this);
        locatorBar = new LocatorBarManager(this);
        teamManager = new TeamManager(this);
        smithZoneManager = new MaceSmithZoneManager(this);
        int total = 0;
        MaceTier tier = MaceTier.DEFAULT;
        while (tier != MaceTier.NETHERITE) {
            total += requiredKills(tier);
            tier = tier.next();
        }
        getLogger().info("Default-config kills required for Netherite: " + total);
        if (total != 12) getLogger().warning("Configured progression reaches Netherite in " + total + " kills, not the default target of 12.");
        listener = new MaceListener(this);
        Bukkit.getPluginManager().registerEvents(listener, this);
        abilityManager = new AbilityManager(this);
        Bukkit.getPluginManager().registerEvents(abilityManager, this);
        maceEncyclopedia = new MaceEncyclopedia(this);
        Bukkit.getPluginManager().registerEvents(maceEncyclopedia, this);
        villagerManager = new VillagerManager(this);
        Bukkit.getPluginManager().registerEvents(villagerManager, this);
        Bukkit.getPluginManager().registerEvents(smithZoneManager, this);
        Bukkit.getPluginManager().registerEvents(new TeamChatListener(teamManager), this);
        MaceCommand command = new MaceCommand(this);
        getCommand("mace").setExecutor(command);
        getCommand("mace").setTabCompleter(command);
        getCommand("macesmith").setExecutor(villagerManager);
        getCommand("macesmith").setTabCompleter(villagerManager);
        TeamCommand teamCommand = new TeamCommand(this);
        getCommand("team").setExecutor(teamCommand);
        getCommand("team").setTabCompleter(teamCommand);
        for (Player player : Bukkit.getOnlinePlayers()) initializePlayer(player);
        for (Player player : Bukkit.getOnlinePlayers()) teamManager.refreshTabName(player);
    }

    @Override
    public void onDisable() {
        if (locatorBar != null) locatorBar.restoreAll();
        if (maceEncyclopedia != null) maceEncyclopedia.shutdown();
        if (abilityManager != null) abilityManager.shutdown();
        if (villagerManager != null) villagerManager.shutdown();
        if (smithZoneManager != null) smithZoneManager.shutdown();
        if (playerData != null) playerData.save();
        if (teamManager != null) teamManager.save();
    }

    public void initializePlayer(Player player) {
        PlayerProgress data = playerData.get(player.getUniqueId());
        normalizeInventory(player);
        refreshMace(player);
        if (!hasOwnedMace(player)) giveMace(player, itemFactory.create(player, data.getTier(), data));
        locatorBar.apply(player, data.getTier(), false);
    }

    public void sendResourcePack(Player player) {
        String url = getConfig().getString("resource_pack.url", "");
        if (url == null || url.isBlank()) return;
        String sha1 = getConfig().getString("resource_pack.sha1", "");
        byte[] hash = null;
        if (sha1 != null && !sha1.isBlank()) {
            try {
                if (!sha1.matches("(?i)[0-9a-f]{40}")) throw new IllegalArgumentException("SHA-1 must contain 40 hexadecimal characters");
                hash = java.util.HexFormat.of().parseHex(sha1);
            } catch (IllegalArgumentException exception) {
                getLogger().warning("Resource pack not sent: invalid resource_pack.sha1 (" + exception.getMessage() + ")");
                return;
            }
        }
        String promptText = getConfig().getString("resource_pack.prompt", "");
        net.kyori.adventure.text.Component prompt = promptText == null || promptText.isBlank()
                ? null : MiniMessage.miniMessage().deserialize(promptText);
        java.util.UUID id = java.util.UUID.nameUUIDFromBytes("maceprogression:resource_pack".getBytes(java.nio.charset.StandardCharsets.UTF_8));
        player.setResourcePack(id, url, hash, prompt, getConfig().getBoolean("resource_pack.force", false));
    }

    public void normalizeInventory(Player player) {
        boolean foundOwnedMace = false;
        for (int slot = 0; slot < player.getInventory().getSize(); slot++) {
            var item = player.getInventory().getItem(slot);
            if (!itemFactory.isPluginMace(item)) continue;
            if (getConfig().getBoolean("remove_mace_if_not_owner", true) && !itemFactory.isOwnedBy(item, player.getUniqueId())) {
                player.getInventory().setItem(slot, null);
                continue;
            }
            if (itemFactory.isOwnedBy(item, player.getUniqueId())) {
                if (foundOwnedMace) player.getInventory().setItem(slot, null);
                else foundOwnedMace = true;
            }
        }
    }

    public boolean hasOwnedMace(Player player) {
        for (int slot = 0; slot < player.getInventory().getSize(); slot++) {
            if (itemFactory.isOwnedBy(player.getInventory().getItem(slot), player.getUniqueId())) return true;
        }
        return false;
    }

    public void replaceMace(Player player, MaceTier tier) {
        PlayerProgress progress = playerData.get(player.getUniqueId());
        boolean foundMace = false;
        for (int slot = 0; slot < player.getInventory().getSize(); slot++) {
            var item = player.getInventory().getItem(slot);
            if (itemFactory.isOwnedBy(item, player.getUniqueId())) {
                if (foundMace) player.getInventory().setItem(slot, null);
                else {
                    itemFactory.update(item, tier, progress);
                    foundMace = true;
                }
            }
        }
        if (!foundMace) giveMace(player, itemFactory.create(player, tier, progress));
    }

    public void restoreMaceAtSlot(Player player, int slot) {
        restoreMaceAtSlot(player, slot, null);
    }

    public void restoreMaceAtSlot(Player player, int slot, org.bukkit.inventory.ItemStack previousMace) {
        for (int current = 0; current < player.getInventory().getSize(); current++) {
            if (itemFactory.isOwnedBy(player.getInventory().getItem(current), player.getUniqueId())) {
                player.getInventory().setItem(current, null);
            }
        }
        PlayerProgress progress = playerData.get(player.getUniqueId());
        var replacement = previousMace == null ? itemFactory.create(player, progress.getTier(), progress) : previousMace;
        itemFactory.update(replacement, progress.getTier(), progress);
        if (slot >= 0 && slot < player.getInventory().getSize()) player.getInventory().setItem(slot, replacement);
        else giveMace(player, replacement);
    }

    private void giveMace(Player player, org.bukkit.inventory.ItemStack mace) {
        player.getInventory().addItem(mace).values().forEach(item ->
                player.getWorld().dropItemNaturally(player.getLocation(), item));
    }

    public void refreshMace(Player player) {
        PlayerProgress progress = playerData.get(player.getUniqueId());
        boolean foundMace = false;
        for (int slot = 0; slot < player.getInventory().getSize(); slot++) {
            var item = player.getInventory().getItem(slot);
            if (!itemFactory.isOwnedBy(item, player.getUniqueId())) continue;
            if (foundMace) player.getInventory().setItem(slot, null);
            else {
                itemFactory.update(item, progress.getTier(), progress);
                foundMace = true;
            }
        }
    }

    public int requiredKills(MaceTier current) {
        if (current == null || current.ordinal() >= MaceTier.NETHERITE.ordinal()) return 0;
        MaceTier next = current.next();
        if (next == null || next.requirementKey() == null) return 0;
        return Math.max(1, getConfig().getInt("kills_required." + next.requirementKey(), 1));
    }

    public String message(String key) {
        return getConfig().getString("messages." + key, "");
    }

    public void send(Player player, String key, java.util.Map<String, String> replacements) {
        String text = message(key);
        for (var entry : replacements.entrySet()) text = text.replace("<" + entry.getKey() + ">", entry.getValue());
        player.sendMessage(MiniMessage.miniMessage().deserialize(getConfig().getString("messages.prefix", "") + text));
    }

    public PlayerDataManager playerData() { return playerData; }
    public MaceItemFactory itemFactory() { return itemFactory; }
    public LocatorBarManager locatorBar() { return locatorBar; }
    public MaceListener listener() { return listener; }
    public AbilityManager abilityManager() { return abilityManager; }
    public VillagerManager villagerManager() { return villagerManager; }
    public TeamManager teamManager() { return teamManager; }
    public MaceSmithZoneManager smithZoneManager() { return smithZoneManager; }
    public MaceEncyclopedia maceEncyclopedia() { return maceEncyclopedia; }
    public NamespacedKey locatorFlagKey() { return locatorFlagKey; }
}
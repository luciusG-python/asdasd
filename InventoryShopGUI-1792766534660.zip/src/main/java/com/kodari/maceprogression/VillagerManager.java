package com.kodari.maceprogression;

import com.cryptomorin.xseries.XMaterial;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityBreedEvent;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerLeashEntityEvent;
import org.bukkit.event.entity.VillagerCareerChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.world.ChunkUnloadEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Merchant;
import org.bukkit.inventory.MerchantInventory;
import org.bukkit.inventory.MerchantRecipe;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class VillagerManager implements Listener, CommandExecutor, TabCompleter {
    private final MaceProgressionPlugin plugin;
    private final NamespacedKey smithKey;
    private final Map<UUID, SmithSession> sessions = new HashMap<>();
    private static final int EGG_SLOT = 0;
    private static final int HEADS_SLOT = 1;
    private static final int OUTPUT_SLOT = 2;

    public VillagerManager(MaceProgressionPlugin plugin) {
        this.plugin = plugin;
        this.smithKey = new NamespacedKey(plugin, "mace_smith");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("maceprogression.admin")) {
            sender.sendMessage(MiniMessage.miniMessage().deserialize(plugin.getConfig().getString("messages.prefix", "")
                    + plugin.message("no_permission")));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage("/macesmith <spawn|remove>");
            return true;
        }
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command can only be used by a player.");
            return true;
        }
        if (args[0].equalsIgnoreCase("spawn")) {
            spawn(player.getLocation());
            player.sendMessage(MiniMessage.miniMessage().deserialize("<green>Mace Smith spawned."));
            return true;
        }
        if (args[0].equalsIgnoreCase("remove")) {
            Villager nearest = player.getNearbyEntities(10, 10, 10).stream()
                    .filter(Villager.class::isInstance).map(Villager.class::cast)
                    .filter(this::isSmith)
                    .filter(villager -> villager.getLocation().distanceSquared(player.getLocation()) <= 100)
                    .min(java.util.Comparator.comparingDouble(villager -> villager.getLocation().distanceSquared(player.getLocation())))
                    .orElse(null);
            if (nearest == null) player.sendMessage(MiniMessage.miniMessage().deserialize("<red>No Mace Smith is within 10 blocks."));
            else {
                closeSessions(nearest.getUniqueId());
                plugin.smithZoneManager().untrackSmith(nearest.getUniqueId());
                nearest.remove();
                player.sendMessage(MiniMessage.miniMessage().deserialize("<green>Mace Smith removed."));
            }
            return true;
        }
        sender.sendMessage("/macesmith <spawn|remove>");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1) return List.of();
        return List.of("spawn", "remove").stream()
                .filter(value -> value.regionMatches(true, 0, args[0], 0, args[0].length())).toList();
    }

    @EventHandler
    public void onInteract(PlayerInteractEntityEvent event) {
        if (!(event.getRightClicked() instanceof Villager villager) || !isSmith(villager)) return;
        event.setCancelled(true);
        if (event.getHand() != EquipmentSlot.HAND) return;
        Player player = event.getPlayer();
        ItemStack output = plugin.itemFactory().create(player, MaceTier.RAINBOW,
                plugin.playerData().get(player.getUniqueId()));
        Merchant merchant = Bukkit.createMerchant("Mace Smith");
        MerchantRecipe recipe = new MerchantRecipe(output, Integer.MAX_VALUE);
        recipe.addIngredient(XMaterial.matchXMaterial("DRAGON_EGG").map(XMaterial::parseItem).orElseThrow());
        ItemStack heads = XMaterial.matchXMaterial("PLAYER_HEAD").map(XMaterial::parseItem).orElseThrow();
        heads.setAmount(2);
        recipe.addIngredient(heads);
        merchant.setRecipes(List.of(recipe));
        player.openMerchant(merchant, true);
        Inventory tradeInventory = player.getOpenInventory().getTopInventory();
        sessions.put(player.getUniqueId(), new SmithSession(villager.getUniqueId(),
                villager.getWorld().getUID(), villager.getChunk().getX(), villager.getChunk().getZ(), tradeInventory));
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player) || !isTradeInventory(event.getView().getTopInventory())) return;
        Inventory inventory = event.getView().getTopInventory();
        int rawSlot = event.getRawSlot();
        if (rawSlot == OUTPUT_SLOT) {
            event.setCancelled(true);
            completeTrade(player, inventory);
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (isTradeInventory(event.getView().getTopInventory())
                && plugin.itemFactory().isPluginMace(event.getOldCursor())) event.setCancelled(true);
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)
                || !(event.getInventory() instanceof MerchantInventory inventory)) return;
        SmithSession session = sessions.get(player.getUniqueId());
        if (session == null || session.inventory() != inventory) return;
        sessions.remove(player.getUniqueId(), session);
        returnMenuItems(player, inventory);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        SmithSession session = sessions.remove(event.getPlayer().getUniqueId());
        if (session != null) returnMenuItems(event.getPlayer(), session.inventory());
    }

    @EventHandler
    public void onChunkUnload(ChunkUnloadEvent event) {
        Chunk chunk = event.getChunk();
        List<UUID> smithIds = new ArrayList<>();
        for (Entity entity : chunk.getEntities()) if (entity instanceof Villager villager && isSmith(villager)) smithIds.add(villager.getUniqueId());
        if (smithIds.isEmpty()) return;
        List<UUID> toClose = sessions.entrySet().stream()
                .filter(entry -> entry.getValue().worldId().equals(chunk.getWorld().getUID())
                        && entry.getValue().chunkX() == chunk.getX() && entry.getValue().chunkZ() == chunk.getZ()
                        && smithIds.contains(entry.getValue().smithId()))
                .map(Map.Entry::getKey).toList();
        for (UUID playerId : toClose) {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null) player.closeInventory();
            sessions.remove(playerId);
        }
    }

    @EventHandler
    public void onDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Villager villager && isSmith(villager)) event.setCancelled(true);
    }

    @EventHandler
    public void onCombust(EntityCombustEvent event) {
        if (event.getEntity() instanceof Villager villager && isSmith(villager)) event.setCancelled(true);
    }

    @EventHandler
    public void onCareerChange(VillagerCareerChangeEvent event) {
        if (isSmith(event.getEntity())) event.setCancelled(true);
    }

    @EventHandler
    public void onBreed(EntityBreedEvent event) {
        if (event.getMother() instanceof Villager mother && isSmith(mother)
                || event.getFather() instanceof Villager father && isSmith(father)) event.setCancelled(true);
    }

    @EventHandler
    public void onLeash(PlayerLeashEntityEvent event) {
        if (event.getEntity() instanceof Villager villager && isSmith(villager)) event.setCancelled(true);
    }

    private Villager spawn(Location location) {
        Villager smith = location.getWorld().spawn(location, Villager.class, villager -> {
            villager.setCustomName(org.bukkit.ChatColor.LIGHT_PURPLE + "Mace Smith");
            villager.setCustomNameVisible(true);
            villager.setInvulnerable(true);
            villager.setAI(false);
            villager.setSilent(true);
            villager.setPersistent(true);
            villager.setRemoveWhenFarAway(false);
            villager.setCollidable(false);
            villager.getPersistentDataContainer().set(smithKey, PersistentDataType.BYTE, (byte) 1);
        });
        plugin.smithZoneManager().trackSmith(smith);
        return smith;
    }

    private void completeTrade(Player player, Inventory inventory) {
        ItemStack heldMain = player.getInventory().getItemInMainHand();
        ItemStack heldOff = player.getInventory().getItemInOffHand();
        if (!validNetheriteMace(heldMain, player.getUniqueId()) && !validNetheriteMace(heldOff, player.getUniqueId())) {
            player.sendMessage(MiniMessage.miniMessage().deserialize("<red>You need to hold your own Netherite Mace to craft the Rainbow Mace."));
            return;
        }
        ItemStack egg = inventory.getItem(EGG_SLOT);
        ItemStack heads = inventory.getItem(HEADS_SLOT);
        if (!isDragonEgg(egg) || heads == null || heads.getAmount() < 2 || playerHeadOwner(heads) == null) {
            player.sendMessage(MiniMessage.miniMessage().deserialize(
                    "<red>Place 1 Dragon Egg and 2 owned player heads in the input slots."));
            return;
        }

        consumeAmount(inventory, EGG_SLOT, 1);
        consumeAmount(inventory, HEADS_SLOT, 2);
        PlayerProgress progress = plugin.playerData().get(player.getUniqueId());
        progress.setTier(MaceTier.RAINBOW);
        progress.setKillsTowardNextTier(0);
        plugin.replaceMace(player, MaceTier.RAINBOW);
        plugin.locatorBar().apply(player, MaceTier.RAINBOW, true);
        plugin.playerData().save();
        Bukkit.getScheduler().runTask(plugin, () -> player.closeInventory());
        player.sendMessage(MiniMessage.miniMessage().deserialize(plugin.getConfig().getString(
                "messages.mace_smith_trade_success", "<light_purple>Your Netherite Mace became a Rainbow Mace!")));
    }

    private boolean validNetheriteMace(ItemStack item, UUID owner) {
        return owner != null && plugin.itemFactory().isOwnedBy(item, owner)
                && plugin.itemFactory().tierOf(item) == MaceTier.NETHERITE;
    }

    private boolean isDragonEgg(ItemStack item) {
        if (item == null || item.getType().isAir()) return false;
        XMaterial expected = XMaterial.matchXMaterial("DRAGON_EGG").orElse(null);
        return expected != null && XMaterial.matchXMaterial(item.getType()) == expected;
    }

    private UUID playerHeadOwner(ItemStack item) {
        if (!isPlayerHead(item) || !(item.getItemMeta() instanceof SkullMeta skullMeta) || skullMeta.getOwningPlayer() == null) return null;
        return skullMeta.getOwningPlayer().getUniqueId();
    }

    private boolean isPlayerHead(ItemStack item) {
        return item != null && !item.getType().isAir() && XMaterial.matchXMaterial(item.getType()).name().equals("PLAYER_HEAD");
    }

    private void consumeAmount(Inventory inventory, int slot, int amount) {
        ItemStack item = inventory.getItem(slot);
        if (item == null || item.getAmount() <= amount) inventory.setItem(slot, null);
        else {
            ItemStack remaining = item.clone();
            remaining.setAmount(remaining.getAmount() - amount);
            inventory.setItem(slot, remaining);
        }
    }

    private void returnMenuItems(Player player, Inventory inventory) {
        for (int slot : new int[]{EGG_SLOT, HEADS_SLOT}) {
            ItemStack item = inventory.getItem(slot);
            if (item == null || item.getType().isAir()) continue;
            inventory.setItem(slot, null);
            Map<Integer, ItemStack> leftovers = player.getInventory().addItem(item.clone());
            leftovers.values().forEach(leftover -> player.getWorld().dropItemNaturally(player.getLocation(), leftover));
        }
    }

    private boolean isSmith(Villager villager) {
        return villager.getPersistentDataContainer().has(smithKey, PersistentDataType.BYTE);
    }

    public boolean isTradeInventory(org.bukkit.inventory.Inventory inventory) {
        return inventory instanceof MerchantInventory merchantInventory
                && sessions.values().stream().anyMatch(session -> session.inventory() == merchantInventory);
    }

    public void shutdown() {
        for (Map.Entry<UUID, SmithSession> entry : Map.copyOf(sessions).entrySet()) {
            UUID playerId = entry.getKey();
            SmithSession session = entry.getValue();
            Player player = Bukkit.getPlayer(playerId);
            if (player == null) {
                sessions.remove(playerId);
                continue;
            }
            Inventory inventory = player.getOpenInventory().getTopInventory();
            if (inventory == session.inventory()) player.closeInventory();
            else {
                sessions.remove(playerId);
                returnMenuItems(player, session.inventory());
            }
        }
    }

    private void closeSessions(UUID smithId) {
        List<UUID> toClose = sessions.entrySet().stream().filter(entry -> entry.getValue().smithId().equals(smithId))
                .map(Map.Entry::getKey).toList();
        for (UUID playerId : toClose) {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null) player.closeInventory();
            sessions.remove(playerId);
        }
    }

    private record SmithSession(UUID smithId, UUID worldId, int chunkX, int chunkZ, Inventory inventory) { }
}
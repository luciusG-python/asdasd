package com.kodari.maceprogression;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class MaceLoreBuilder {
    private final MaceProgressionPlugin plugin;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();

    public MaceLoreBuilder(MaceProgressionPlugin plugin) {
        this.plugin = plugin;
    }

    public void apply(ItemMeta meta, MaceTier tier, PlayerProgress progress) {
        int required = tier == MaceTier.NETHERITE || tier == MaceTier.RAINBOW ? 0 : plugin.requiredKills(tier);
        int kills = required == 0 ? 0 : Math.min(required, Math.max(0, progress.getKillsTowardNextTier()));
        String tierColor = plugin.getConfig().getString("lore.tier_colors." + tier.key(), defaultTierColor(tier));
        Map<String, String> values = new HashMap<>();
        values.put("%tier%", tier.displayName());
        values.put("%tier_upper%", tier.name());
        values.put("%tier_color%", tierColor);
        values.put("%server_name%", plugin.getConfig().getString("lore.server_name", "Server"));
        values.put("%kills%", Integer.toString(kills));
        values.put("%needed%", Integer.toString(required));
        values.put("%bar%", progressBar(tierColor, kills, required));
        values.put("%locator%", plugin.locatorBar().isUnlocked(tier) ? "<green>ON" : "<red>OFF");

        meta.displayName(render(replace(template("name", "%tier_color%★ %tier% Mace ★"), values)));
        List<Component> lore = new ArrayList<>();
        String enchantments = enchantmentLine(tier);
        if (!enchantments.isBlank()) {
            values.put("%enchantments%", enchantments);
            lore.add(render(replace(template("enchantments", "%tier_color%%enchantments%"), values)));
        }
        lore.add(render(template("blank", "")));
        lore.add(render(replace(template("abilities_header", "%tier_color%Abilities:"), values)));
        appendAbilities(lore, tier, tierColor);
        lore.add(render(template("blank", "")));
        lore.add(render(replace(template("requirements_header", "%tier_color%Next Mace Requirements:"), values)));
        if (tier == MaceTier.RAINBOW) {
            lore.add(render(template("rainbow_max", "<gradient:#ff5555:#55ffff>MAX TIER</gradient>")));
        } else if (tier == MaceTier.NETHERITE) {
            lore.add(render(template("netherite_requirement", "<white>Trade this mace with the Mace Smith villager for the Rainbow Mace.")));
        } else {
            lore.add(render(replace(template("requirement_line", "<white>1. Kill %needed% players using your mace."), values)));
            lore.add(render(replace(template("progress_line", "%bar% <white>[%kills%/%needed%]"), values)));
        }
        lore.add(render(template("blank", "")));
        lore.add(render(replace(template("locator_line", "%tier_color%Locator Bar: %locator%"), values)));
        lore.add(render(replace(template("footer", "%tier_color%<bold>%server_name%'s %tier_upper% MACE"), values)));
        meta.lore(lore);
    }

    private void appendAbilities(List<Component> lore, MaceTier tier, String tierColor) {
        ConfigurationSection abilities = plugin.getConfig().getConfigurationSection("lore.abilities." + tier.key());
        if (abilities == null) return;
        int wrapWidth = Math.max(10, plugin.getConfig().getInt("lore.description_wrap", 35));
        for (String key : abilities.getKeys(false)) {
            ConfigurationSection ability = abilities.getConfigurationSection(key);
            if (ability == null) continue;
            Map<String, String> values = new HashMap<>();
            ConfigurationSection configuredAbility = plugin.getConfig().getConfigurationSection("abilities." + tier.key() + "." + key);
            if (configuredAbility != null) {
                for (String field : configuredAbility.getKeys(false)) {
                    Object value = configuredAbility.get(field);
                    if (value != null && !(value instanceof ConfigurationSection) && !(value instanceof List<?>)) {
                        values.put("%" + field + "%", String.valueOf(value));
                    }
                }
            }
            for (String field : ability.getKeys(false)) {
                Object value = ability.get(field);
                if (value != null && !(value instanceof ConfigurationSection) && !(value instanceof List<?>)) {
                    if (!field.equals("cooldown") || configuredAbility == null || !configuredAbility.contains("cooldown")) {
                        values.put("%" + field + "%", String.valueOf(value));
                    }
                }
            }
            String name = ability.getString("name", key);
            String trigger = ability.getString("trigger", "PASSIVE").toUpperCase(Locale.ROOT);
            Object cooldown = configuredAbility != null && configuredAbility.contains("cooldown")
                    ? configuredAbility.get("cooldown") : ability.get("cooldown");
            Object chance = configuredAbility == null ? null : configuredAbility.get("chance");
            if (chance instanceof Number number) values.put("%chance_percent%", Integer.toString((int) Math.round(number.doubleValue() * 100)));
            values.put("%tier_color%", tierColor);
            values.put("%icon%", ability.getString("icon", "•"));
            values.put("%ability_name%", name);
            values.put("%trigger%", trigger);
            if (cooldown != null) values.put("%cooldown%", String.valueOf(cooldown));
            lore.add(render(replace(template("ability_line", "%tier_color%%icon% %ability_name%: <gray>%trigger%"), values)));

            Object description = ability.get("description");
            List<String> descriptions = new ArrayList<>();
            if (description instanceof List<?> lines) {
                for (Object line : lines) if (line != null) descriptions.add(replace(String.valueOf(line), values));
            } else if (description != null) {
                descriptions.add(replace(String.valueOf(description), values));
            }
            for (String line : descriptions) {
                for (String wrapped : wrap(line, wrapWidth)) {
                    values.put("%description%", wrapped);
                    lore.add(render(replace(template("ability_description_line", "   <gray>%description%"), values)));
                }
            }
            if (!trigger.equals("PASSIVE") && cooldown != null) {
                lore.add(render(replace(template("ability_cooldown_line", "   <dark_gray>Cooldown: %cooldown%s"), values)));
            }
        }
    }

    private String progressBar(String tierColor, int kills, int needed) {
        int segments = Math.max(1, plugin.getConfig().getInt("lore.progress_bar.segments", 16));
        int filledSegments = needed <= 0 ? 0 : (int) Math.floor((double) Math.max(0, kills) * segments / needed);
        filledSegments = Math.min(segments, filledSegments);
        String filled = plugin.getConfig().getString("lore.progress_bar.filled", "■");
        String empty = plugin.getConfig().getString("lore.progress_bar.empty", "□");
        return tierColor + filled.repeat(filledSegments) + "<dark_gray>" + empty.repeat(segments - filledSegments);
    }

    private String enchantmentLine(MaceTier tier) {
        ConfigurationSection enchantments = plugin.getConfig().getConfigurationSection("enchantments." + tier.key());
        if (enchantments == null) return "";
        List<String> names = new ArrayList<>();
        for (String key : enchantments.getKeys(false)) {
            names.add(humanize(key) + " " + roman(enchantments.getInt(key, 1)));
        }
        return String.join(", ", names);
    }

    private String humanize(String key) {
        StringBuilder result = new StringBuilder();
        for (String part : key.toLowerCase(Locale.ROOT).split("_")) {
            if (result.length() > 0) result.append(' ');
            result.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return result.toString();
    }

    private String roman(int number) {
        if (number < 1 || number > 3999) return Integer.toString(number);
        int[] values = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] numerals = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        StringBuilder result = new StringBuilder();
        for (int index = 0; index < values.length; index++) {
            while (number >= values[index]) {
                result.append(numerals[index]);
                number -= values[index];
            }
        }
        return result.toString();
    }

    private List<String> wrap(String text, int width) {
        List<String> lines = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : text.trim().split("\\s+")) {
            if (word.isEmpty()) continue;
            if (line.length() > 0 && line.length() + word.length() + 1 > width) {
                lines.add(line.toString());
                line.setLength(0);
            }
            if (line.length() > 0) line.append(' ');
            line.append(word);
        }
        if (line.length() > 0) lines.add(line.toString());
        return lines;
    }

    private String template(String key, String fallback) {
        return plugin.getConfig().getString("lore." + key, fallback);
    }

    private String replace(String text, Map<String, String> values) {
        for (Map.Entry<String, String> entry : values.entrySet()) {
            text = text.replace(entry.getKey(), entry.getValue());
        }
        return text;
    }

    private Component render(String text) {
        return miniMessage.deserialize("<italic:false>" + text);
    }

    private String defaultTierColor(MaceTier tier) {
        return switch (tier) {
            case DEFAULT, IRON -> "<white>";
            case WOODEN -> "<#b77a45>";
            case STONE -> "<gray>";
            case COPPER -> "<#d87942>";
            case GOLD -> "<yellow>";
            case DIAMOND -> "<aqua>";
            case NETHERITE -> "<dark_purple>";
            case RAINBOW -> "<rainbow>";
        };
    }
}
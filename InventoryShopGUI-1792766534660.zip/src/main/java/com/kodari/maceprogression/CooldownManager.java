package com.kodari.maceprogression;

import com.cryptomorin.xseries.XSound;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class CooldownManager {
    private final MaceProgressionPlugin plugin;
    private final Map<CooldownKey, Long> expiresAt = new HashMap<>();
    private final Map<CooldownKey, BukkitTask> tasks = new HashMap<>();

    public CooldownManager(MaceProgressionPlugin plugin) {
        this.plugin = plugin;
    }

    public long remainingSeconds(UUID playerId, String abilityId) {
        Long expiry = expiresAt.get(new CooldownKey(playerId, abilityId));
        if (expiry == null) return 0;
        long remaining = expiry - System.currentTimeMillis();
        return remaining <= 0 ? 0 : (remaining + 999L) / 1000L;
    }

    public void showRemaining(Player player, String abilityName, String abilityId) {
        long seconds = remainingSeconds(player.getUniqueId(), abilityId);
        if (seconds > 0) show(player, abilityName, seconds);
    }

    public void start(Player player, String abilityName, String abilityId, int seconds) {
        if (seconds <= 0) return;
        CooldownKey key = new CooldownKey(player.getUniqueId(), abilityId);
        BukkitTask previous = tasks.remove(key);
        if (previous != null) previous.cancel();
        expiresAt.put(key, System.currentTimeMillis() + seconds * 1000L);
        show(player, abilityName, seconds);
        tasks.put(key, Bukkit.getScheduler().runTaskTimer(plugin, () -> tick(key, abilityName), 20L, 20L));
    }

    public void clear(UUID playerId) {
        expiresAt.keySet().removeIf(key -> key.playerId().equals(playerId));
        tasks.entrySet().removeIf(entry -> {
            if (!entry.getKey().playerId().equals(playerId)) return false;
            entry.getValue().cancel();
            return true;
        });
    }

    public void shutdown() {
        tasks.values().forEach(BukkitTask::cancel);
        tasks.clear();
        expiresAt.clear();
    }

    private void tick(CooldownKey key, String abilityName) {
        Player player = Bukkit.getPlayer(key.playerId());
        long remaining = remainingSeconds(key.playerId(), key.abilityId());
        if (remaining <= 0) {
            expiresAt.remove(key);
            BukkitTask task = tasks.remove(key);
            if (task != null) task.cancel();
            if (player != null) {
                XSound.matchXSound("BLOCK_NOTE_BLOCK_PLING").ifPresent(sound -> sound.play(player));
                String ready = plugin.getConfig().getString("messages.ability_ready", "<green>%ability% is ready!")
                        .replace("%ability%", abilityName);
                player.sendActionBar(MiniMessage.miniMessage().deserialize(ready));
            }
            return;
        }
        if (player != null) show(player, abilityName, remaining);
    }

    private void show(Player player, String abilityName, long seconds) {
        String message = plugin.getConfig().getString("messages.ability_cooldown", "<yellow>%ability%: %seconds%s")
                .replace("%ability%", abilityName)
                .replace("%seconds%", Long.toString(seconds));
        player.sendActionBar(MiniMessage.miniMessage().deserialize(message));
    }

    private record CooldownKey(UUID playerId, String abilityId) { }
}
package com.kodari.maceprogression;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class TeamCommand implements CommandExecutor, TabCompleter {
    private static final List<String> SUBCOMMANDS = List.of("create", "invite", "accept", "deny", "leader", "leave", "kick", "disband", "info", "list");
    private final MaceProgressionPlugin plugin;
    private final TeamManager teams;

    public TeamCommand(MaceProgressionPlugin plugin) {
        this.plugin = plugin;
        this.teams = plugin.teamManager();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("maceprogression.team.use")) {
            sender.sendMessage("You do not have permission to use team commands.");
            return true;
        }
        if (args.length == 0) {
            sendUsage(sender, label);
            return true;
        }
        String action = args[0].toLowerCase(Locale.ROOT);
        if (action.equals("list")) {
            List<String> names = teams.teamNames();
            sender.sendMessage(names.isEmpty() ? "There are no teams." : "Teams: " + String.join(", ", names));
            return true;
        }
        if (action.equals("info")) {
            String name = args.length > 1 ? args[1] : sender instanceof Player player ? teams.teamNameFor(player) : null;
            if (name == null) {
                sender.sendMessage("Usage: /" + label + " info <team>");
                return true;
            }
            List<String> info = teams.info(name);
            if (info == null) sender.sendMessage("That team does not exist.");
            else info.forEach(sender::sendMessage);
            return true;
        }
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use that team command.");
            return true;
        }
        switch (action) {
            case "create" -> {
                if (args.length != 2) sender.sendMessage("Usage: /" + label + " create <name>");
                else {
                    String error = teams.create(player, args[1]);
                    sender.sendMessage(error == null ? "Team " + args[1] + " created. You are the leader." : error);
                }
            }
            case "invite" -> {
                if (args.length != 2) sender.sendMessage("Usage: /" + label + " invite <player>");
                else {
                    Player target = Bukkit.getPlayerExact(args[1]);
                    if (target == null) sender.sendMessage("That player is not online.");
                    else sender.sendMessage(teams.invite(player, target));
                }
            }
            case "accept" -> sender.sendMessage(teams.accept(player, args.length > 1 ? args[1] : null));
            case "deny" -> sender.sendMessage(teams.deny(player, args.length > 1 ? args[1] : null));
            case "leader" -> {
                if (args.length != 2) sender.sendMessage("Usage: /" + label + " leader <player>");
                else {
                    Player target = Bukkit.getPlayerExact(args[1]);
                    if (target == null) sender.sendMessage("That player is not online.");
                    else sender.sendMessage(teams.transferLeadership(player, target));
                }
            }
            case "leave" -> sender.sendMessage(teams.leave(player));
            case "kick" -> {
                if (args.length != 2) sender.sendMessage("Usage: /" + label + " kick <player>");
                else {
                    Player target = Bukkit.getPlayerExact(args[1]);
                    if (target == null) sender.sendMessage("That player is not online.");
                    else sender.sendMessage(teams.kick(player, target));
                }
            }
            case "disband" -> sender.sendMessage(teams.disband(player));
            default -> sendUsage(sender, label);
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("maceprogression.team.use")) return List.of();
        if (args.length == 1) return matching(SUBCOMMANDS, args[0]);
        if (args.length == 2) {
            String action = args[0].toLowerCase(Locale.ROOT);
            if (action.equals("invite")) return matching(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[1]);
            if (action.equals("accept") || action.equals("deny")) return matching(teams.pendingInviteNames(sender instanceof Player player ? player.getUniqueId() : null), args[1]);
            if (action.equals("info")) return matching(teams.teamNames(), args[1]);
            if ((action.equals("leader") || action.equals("kick")) && sender instanceof Player player) {
                return matching(teams.onlineMemberNames(player.getUniqueId()), args[1]);
            }
        }
        return List.of();
    }

    private List<String> matching(List<String> options, String prefix) {
        String normalized = prefix.toLowerCase(Locale.ROOT);
        List<String> matches = new ArrayList<>();
        for (String option : options) if (option.toLowerCase(Locale.ROOT).startsWith(normalized)) matches.add(option);
        return matches;
    }

    private void sendUsage(CommandSender sender, String label) {
        sender.sendMessage("Usage: /" + label + " <create|invite|accept|deny|leader|leave|kick|disband|info|list>");
    }
}
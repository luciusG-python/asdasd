package com.kodari.maceprogression;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

public final class TeamManager {
    private static final Pattern VALID_NAME = Pattern.compile("[A-Za-z0-9_]+");

    private final MaceProgressionPlugin plugin;
    private final File file;
    private final Map<String, TeamData> teams = new HashMap<>();
    private final Map<UUID, TeamData> memberships = new ConcurrentHashMap<>();
    private final Map<UUID, Map<String, Long>> invites = new HashMap<>();

    public TeamManager(MaceProgressionPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "teams.yml");
        load();
    }

    public String create(Player creator, String name) {
        int minLength = Math.max(1, plugin.getConfig().getInt("teams.name_min_length", 2));
        int maxLength = Math.max(minLength, plugin.getConfig().getInt("teams.name_max_length", 16));
        if (name == null || name.length() < minLength || name.length() > maxLength || !VALID_NAME.matcher(name).matches()) {
            return "Team names must be " + minLength + "-" + maxLength + " characters and use only letters, numbers, or underscores.";
        }
        if (memberships.containsKey(creator.getUniqueId())) return "You are already in a team.";
        String key = key(name);
        if (teams.containsKey(key)) return "A team with that name already exists.";
        TeamData team = new TeamData(name, creator.getUniqueId());
        teams.put(key, team);
        memberships.put(creator.getUniqueId(), team);
        save();
        refreshTabName(creator);
        return null;
    }

    public String invite(Player inviter, Player target) {
        TeamData team = memberships.get(inviter.getUniqueId());
        if (team == null || !team.leader.equals(inviter.getUniqueId())) return "Only your team leader can invite players.";
        if (inviter.equals(target)) return "You cannot invite yourself.";
        if (memberships.containsKey(target.getUniqueId())) return "That player is already in a team.";
        String teamKey = key(team.name);
        long timeout = Math.max(1L, plugin.getConfig().getLong("teams.invite_timeout_seconds", 60));
        long expiresAt = System.currentTimeMillis() + timeout * 1000L;
        invites.computeIfAbsent(target.getUniqueId(), ignored -> new HashMap<>()).put(teamKey, expiresAt);
        target.sendMessage("You were invited to team " + team.name + ". Use /team accept " + team.name + " or /team deny " + team.name + ".");
        return "Invite sent to " + target.getName() + ". It expires in " + timeout + " seconds.";
    }

    public String accept(Player player, String teamName) {
        if (memberships.containsKey(player.getUniqueId())) return "You are already in a team.";
        Map<String, Long> playerInvites = validInvites(player.getUniqueId());
        if (playerInvites.isEmpty()) return "You have no pending team invites.";
        String selected = selectInvite(playerInvites, teamName);
        if (selected == null) return teamName == null
                ? "You have several invites. Use /team accept <team>."
                : "You do not have a valid invite from that team.";
        TeamData team = teams.get(selected);
        if (team == null) return "That team no longer exists.";
        team.members.add(player.getUniqueId());
        memberships.put(player.getUniqueId(), team);
        invites.remove(player.getUniqueId());
        save();
        refreshTabName(player);
        return "You joined team " + team.name + ".";
    }

    public String deny(Player player, String teamName) {
        Map<String, Long> playerInvites = validInvites(player.getUniqueId());
        if (playerInvites.isEmpty()) return "You have no pending team invites.";
        String selected = selectInvite(playerInvites, teamName);
        if (selected == null) return teamName == null
                ? "You have several invites. Use /team deny <team>."
                : "You do not have a valid invite from that team.";
        playerInvites.remove(selected);
        if (playerInvites.isEmpty()) invites.remove(player.getUniqueId());
        TeamData team = teams.get(selected);
        return "You denied the invite from " + (team == null ? teamName : team.name) + ".";
    }

    public String leave(Player player) {
        TeamData team = memberships.get(player.getUniqueId());
        if (team == null) return "You are not in a team.";
        removeMember(team, player.getUniqueId());
        if (team.members.isEmpty()) teams.remove(key(team.name));
        else if (team.leader.equals(player.getUniqueId())) team.leader = team.members.get(0);
        save();
        refreshTabName(player);
        if (!team.members.isEmpty()) refreshOnlineMembers(team);
        return team.members.isEmpty() ? "You left and disbanded team " + team.name + "."
                : "You left team " + team.name + ".";
    }

    public String transferLeadership(Player leader, Player target) {
        TeamData team = memberships.get(leader.getUniqueId());
        if (team == null || !team.leader.equals(leader.getUniqueId())) return "Only your team leader can transfer leadership.";
        if (memberships.get(target.getUniqueId()) != team) return "That player is not a member of your team.";
        team.leader = target.getUniqueId();
        save();
        target.sendMessage("You are now the leader of team " + team.name + ".");
        return "Leadership of " + team.name + " was transferred to " + target.getName() + ".";
    }

    public String kick(Player leader, Player target) {
        TeamData team = memberships.get(leader.getUniqueId());
        if (team == null || !team.leader.equals(leader.getUniqueId())) return "Only your team leader can kick members.";
        if (target.getUniqueId().equals(leader.getUniqueId())) return "Use /team leave to leave your team.";
        if (memberships.get(target.getUniqueId()) != team) return "That player is not a member of your team.";
        removeMember(team, target.getUniqueId());
        save();
        refreshTabName(target);
        target.sendMessage("You were kicked from team " + team.name + ".");
        return "You kicked " + target.getName() + " from team " + team.name + ".";
    }

    public String disband(Player leader) {
        TeamData team = memberships.get(leader.getUniqueId());
        if (team == null || !team.leader.equals(leader.getUniqueId())) return "Only your team leader can disband the team.";
        teams.remove(key(team.name));
        for (UUID member : List.copyOf(team.members)) {
            memberships.remove(member);
            Player online = Bukkit.getPlayer(member);
            if (online != null) refreshTabName(online);
        }
        removeInvitesForTeam(key(team.name));
        team.members.clear();
        save();
        return "Team " + team.name + " was disbanded.";
    }

    public boolean areTeammates(UUID first, UUID second) {
        TeamData team = memberships.get(first);
        return team != null && team == memberships.get(second);
    }

    public String teamName(UUID playerId) {
        TeamData team = memberships.get(playerId);
        return team == null ? null : team.name;
    }

    public void refreshTabName(Player player) {
        String team = teamName(player.getUniqueId());
        player.playerListName(Component.text(team == null ? player.getName() : team + " | " + player.getName()));
    }

    public List<String> pendingInviteNames(UUID playerId) {
        Map<String, Long> pending = validInvites(playerId);
        List<String> names = new ArrayList<>();
        for (String invite : pending.keySet()) {
            TeamData team = teams.get(invite);
            if (team != null) names.add(team.name);
        }
        names.sort(String.CASE_INSENSITIVE_ORDER);
        return names;
    }

    public List<String> teamNames() {
        return teams.values().stream().map(team -> team.name).sorted(String.CASE_INSENSITIVE_ORDER).toList();
    }

    public List<String> onlineMemberNames(UUID playerId) {
        TeamData team = memberships.get(playerId);
        if (team == null) return List.of();
        List<String> names = new ArrayList<>();
        for (UUID member : team.members) {
            Player online = Bukkit.getPlayer(member);
            if (online != null) names.add(online.getName());
        }
        names.sort(String.CASE_INSENSITIVE_ORDER);
        return names;
    }

    public List<String> info(String teamName) {
        TeamData team = teams.get(key(teamName));
        if (team == null) return null;
        List<String> members = new ArrayList<>();
        for (UUID member : team.members) members.add(playerName(member));
        String leaderName = playerName(team.leader);
        return List.of("Team " + team.name + " | Leader: " + leaderName,
                "Members (" + members.size() + "): " + String.join(", ", members));
    }

    public String teamNameFor(Player player) {
        return teamName(player.getUniqueId());
    }

    public void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        List<Map<String, Object>> storedTeams = new ArrayList<>();
        for (TeamData team : teams.values()) {
            Map<String, Object> stored = new HashMap<>();
            stored.put("name", team.name);
            stored.put("leader", team.leader.toString());
            stored.put("members", team.members.stream().map(UUID::toString).toList());
            storedTeams.add(stored);
        }
        yaml.set("teams", storedTeams);
        try {
            yaml.save(file);
        } catch (IOException exception) {
            plugin.getLogger().severe("Could not save teams.yml: " + exception.getMessage());
        }
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        for (Map<?, ?> stored : yaml.getMapList("teams")) {
            Object nameValue = stored.get("name");
            Object leaderValue = stored.get("leader");
            if (nameValue == null || leaderValue == null) continue;
            String name = String.valueOf(nameValue);
            if (!VALID_NAME.matcher(name).matches() || teams.containsKey(key(name))) continue;
            UUID leader;
            try {
                leader = UUID.fromString(String.valueOf(leaderValue));
            } catch (IllegalArgumentException exception) {
                continue;
            }
            TeamData team = new TeamData(name, leader);
            Object memberValue = stored.get("members");
            if (memberValue instanceof Iterable<?> values) {
                for (Object value : values) {
                    try {
                        UUID member = UUID.fromString(String.valueOf(value));
                        if (!team.members.contains(member)) team.members.add(member);
                    } catch (IllegalArgumentException ignored) { }
                }
            }
            if (!team.members.contains(leader)) team.members.add(0, leader);
            team.members.removeIf(member -> memberships.containsKey(member));
            if (team.members.isEmpty()) continue;
            if (!team.members.contains(leader)) team.leader = team.members.get(0);
            teams.put(key(name), team);
            for (UUID member : team.members) memberships.put(member, team);
        }
    }

    private void removeMember(TeamData team, UUID player) {
        team.members.remove(player);
        memberships.remove(player);
    }

    private void refreshOnlineMembers(TeamData team) {
        for (UUID member : team.members) {
            Player online = Bukkit.getPlayer(member);
            if (online != null) refreshTabName(online);
        }
    }

    private Map<String, Long> validInvites(UUID player) {
        Map<String, Long> playerInvites = invites.get(player);
        if (playerInvites == null) return new HashMap<>();
        long now = System.currentTimeMillis();
        playerInvites.entrySet().removeIf(entry -> entry.getValue() <= now || !teams.containsKey(entry.getKey()));
        if (playerInvites.isEmpty()) invites.remove(player);
        return playerInvites;
    }

    private String selectInvite(Map<String, Long> pending, String teamName) {
        if (teamName == null || teamName.isBlank()) return pending.size() == 1 ? pending.keySet().iterator().next() : null;
        String selected = key(teamName);
        return pending.containsKey(selected) ? selected : null;
    }

    private void removeInvitesForTeam(String teamKey) {
        Iterator<Map.Entry<UUID, Map<String, Long>>> iterator = invites.entrySet().iterator();
        while (iterator.hasNext()) {
            Map<String, Long> playerInvites = iterator.next().getValue();
            playerInvites.remove(teamKey);
            if (playerInvites.isEmpty()) iterator.remove();
        }
    }

    private String playerName(UUID playerId) {
        Player online = Bukkit.getPlayer(playerId);
        if (online != null) return online.getName();
        String cached = Bukkit.getOfflinePlayer(playerId).getName();
        return cached == null ? playerId.toString().substring(0, 8) : cached;
    }

    private String key(String teamName) {
        return teamName == null ? "" : teamName.toLowerCase(Locale.ROOT);
    }

    private static final class TeamData {
        private final String name;
        private UUID leader;
        private final List<UUID> members = new ArrayList<>();

        private TeamData(String name, UUID leader) {
            this.name = name;
            this.leader = leader;
            this.members.add(leader);
        }
    }
}
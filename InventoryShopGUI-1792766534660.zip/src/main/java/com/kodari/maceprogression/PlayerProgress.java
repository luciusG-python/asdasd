package com.kodari.maceprogression;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Persistent kill and tier data for one player. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PlayerProgress {
    private MaceTier tier = MaceTier.DEFAULT;
    private int totalKills;
    private int killsTowardNextTier;
}
package com.kodari.maceprogression;

import com.cryptomorin.xseries.XAttribute;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Applies per-player waypoint receive/transmit range changes for locator access. */
public final class LocatorBarManager {
    private final MaceProgressionPlugin plugin;
    private final Map<UUID, Double> receiveOriginal = new HashMap<>();
    private final Map<UUID, Double> transmitOriginal = new HashMap<>();

    public LocatorBarManager(MaceProgressionPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isUnlocked(MaceTier tier) {
        if (!plugin.getConfig().getBoolean("locator_bar.enabled", true)) return false;
        if (tier == MaceTier.RAINBOW && !plugin.getConfig().getBoolean("locator_bar.rainbow_keeps_it", true)) return false;
        MaceTier unlock = MaceTier.parse(plugin.getConfig().getString("locator_bar.unlock_tier", "GOLD"));
        if (unlock == null) unlock = MaceTier.GOLD;
        return tier.ordinal() >= unlock.ordinal();
    }

    public void apply(Player player, MaceTier tier, boolean notify) {
        boolean enabled = plugin.getConfig().getBoolean("locator_bar.enabled", true);
        boolean unlocked = enabled && isUnlocked(tier);
        setRange(player, "waypoint_receive_range", unlocked, receiveOriginal);
        boolean transmit = plugin.getConfig().getBoolean("locator_bar.transmit_for_all", true) || unlocked;
        setRange(player, "waypoint_transmit_range", transmit, transmitOriginal);
        player.getPersistentDataContainer().set(plugin.locatorFlagKey(), PersistentDataType.BYTE, (byte) 1);
        if (notify && enabled) {
            String path = unlocked ? "locator_bar.unlocked_message" : "locator_bar.lost_message";
            player.sendMessage(MiniMessage.miniMessage().deserialize(plugin.getConfig().getString(path, "")));
        }
    }

    public void restoreAll() {
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            restore(player, "waypoint_receive_range", receiveOriginal);
            restore(player, "waypoint_transmit_range", transmitOriginal);
            player.getPersistentDataContainer().remove(plugin.locatorFlagKey());
        }
    }

    private void setRange(Player player, String name, boolean allowed, Map<UUID, Double> originals) {
        XAttribute.of(name).ifPresent(xAttribute -> {
            AttributeInstance instance = player.getAttribute(xAttribute.get());
            if (instance == null) return;
            originals.putIfAbsent(player.getUniqueId(), instance.getBaseValue());
            instance.setBaseValue(allowed ? originals.get(player.getUniqueId()) : 0.0);
        });
    }

    private void restore(Player player, String name, Map<UUID, Double> originals) {
        XAttribute.of(name).ifPresent(xAttribute -> {
            AttributeInstance instance = player.getAttribute(xAttribute.get());
            if (instance == null) return;
            Double original = originals.remove(player.getUniqueId());
            instance.setBaseValue(original == null ? instance.getDefaultValue() : original);
        });
    }
}
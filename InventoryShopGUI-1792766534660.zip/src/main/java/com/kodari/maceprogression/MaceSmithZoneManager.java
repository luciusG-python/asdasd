package com.kodari.maceprogression;

import com.cryptomorin.xseries.XMaterial;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockFadeEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockMultiPlaceEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockSpreadEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.event.world.ChunkUnloadEvent;
import org.bukkit.event.world.WorldLoadEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class MaceSmithZoneManager implements Listener {
    private final MaceProgressionPlugin plugin;
    private final NamespacedKey smithKey;
    private final File dataFile;
    private final Map<UUID, SmithCenter> smiths = new HashMap<>();
    private final Map<BlockKey, TemporaryBlock> temporaryBlocks = new HashMap<>();
    private final Map<BlockKey, BukkitTask> expiryTasks = new HashMap<>();

    public MaceSmithZoneManager(MaceProgressionPlugin plugin) {
        this.plugin = plugin;
        this.smithKey = new NamespacedKey(plugin, "mace_smith");
        this.dataFile = new File(plugin.getDataFolder(), "mace_smith_zone.yml");
        for (World world : Bukkit.getWorlds()) trackLoadedSmiths(world);
        loadTemporaryBlocks();
    }

    public void trackSmith(Villager smith) {
        if (!isSmith(smith)) return;
        Location location = smith.getLocation();
        smiths.put(smith.getUniqueId(), new SmithCenter(location.getWorld().getUID(), location.getBlockX(), location.getBlockZ()));
    }

    public void untrackSmith(UUID smithId) {
        smiths.remove(smithId);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockBreak(org.bukkit.event.block.BlockBreakEvent event) {
        if (isInside(event.getBlock())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        List<BlockState> replaced = new ArrayList<>();
        if (event instanceof BlockMultiPlaceEvent multiPlace) replaced.addAll(multiPlace.getReplacedBlockStates());
        else replaced.add(event.getBlockReplacedState());

        List<Block> placementBlocks = replaced.stream().map(state -> state.getWorld().getBlockAt(state.getX(), state.getY(), state.getZ())).toList();
        boolean anyInside = placementBlocks.stream().anyMatch(this::isInside);
        if (!anyInside) return;
        if (placementBlocks.stream().anyMatch(block -> !isInside(block))) {
            event.setCancelled(true);
            return;
        }

        Set<BlockKey> placedKeys = new HashSet<>();
        for (Block block : placementBlocks) placedKeys.add(BlockKey.of(block));
        for (int index = 0; index < placementBlocks.size(); index++) {
            Block block = placementBlocks.get(index);
            if (!replaced.get(index).getType().isAir()) {
                rejectPlacement(event);
                return;
            }
            Block support = block.getRelative(BlockFace.DOWN);
            if (!placedKeys.contains(BlockKey.of(support))
                    && (!support.getType().isSolid() || temporaryBlocks.containsKey(BlockKey.of(support)))) {
                rejectPlacement(event);
                return;
            }
        }

        long placedAt = System.currentTimeMillis();
        for (Block block : placementBlocks) {
            BlockKey key = BlockKey.of(block);
            org.bukkit.Material expectedType = event.getBlockPlaced().getType();
            Bukkit.getScheduler().runTask(plugin, () -> trackPlacedBlock(key, expectedType, placedAt));
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onEntityExplosion(EntityExplodeEvent event) {
        event.blockList().removeIf(this::isInside);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockExplosion(BlockExplodeEvent event) {
        event.blockList().removeIf(this::isInside);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockBurn(BlockBurnEvent event) {
        if (isInside(event.getBlock())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockIgnite(BlockIgniteEvent event) {
        if (isInside(event.getBlock()) || (event.getIgnitingBlock() != null && isInside(event.getIgnitingBlock()))) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockSpread(BlockSpreadEvent event) {
        if (isInside(event.getBlock()) || isInside(event.getSource())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockFade(BlockFadeEvent event) {
        if (isInside(event.getBlock())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onLiquidFlow(BlockFromToEvent event) {
        if (isInside(event.getBlock()) || isInside(event.getToBlock())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent event) {
        if (pistonTouchesZone(event.getBlock(), event.getBlocks(), event.getDirection())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent event) {
        if (pistonTouchesZone(event.getBlock(), event.getBlocks(), event.getDirection().getOppositeFace())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent event) {
        Block clicked = event.getBlockClicked();
        if (isInside(clicked) || isInside(clicked.getRelative(event.getBlockFace()))) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent event) {
        Block clicked = event.getBlockClicked();
        if (isInside(clicked) || isInside(clicked.getRelative(event.getBlockFace()))) event.setCancelled(true);
    }

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent event) {
        trackSmiths(event.getChunk());
        scheduleChunkBlocks(event.getChunk());
    }

    @EventHandler
    public void onChunkUnload(ChunkUnloadEvent event) {
        rememberSmithCenters(event.getChunk());
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent event) {
        trackLoadedSmiths(event.getWorld());
        for (BlockKey key : temporaryBlocks.keySet()) {
            if (key.worldId().equals(event.getWorld().getUID()) && event.getWorld().isChunkLoaded(key.x() >> 4, key.z() >> 4)) {
                scheduleExpiry(key);
            }
        }
    }

    public void shutdown() {
        for (BukkitTask task : expiryTasks.values()) task.cancel();
        expiryTasks.clear();
        saveTemporaryBlocks();
    }

    private boolean pistonTouchesZone(Block piston, List<Block> moved, BlockFace movement) {
        if (isInside(piston)) return true;
        for (Block block : moved) {
            if (isInside(block) || isInside(block.getRelative(movement))) return true;
        }
        return false;
    }

    private void rejectPlacement(BlockPlaceEvent event) {
        event.setCancelled(true);
        event.getPlayer().sendMessage("In the Mace Smith zone, place blocks only on top of existing, non-player-placed blocks.");
    }

    private boolean isInside(Block block) {
        World world = block.getWorld();
        int radius = Math.max(0, plugin.getConfig().getInt("mace_smith_zone.radius_blocks", 7));
        for (UUID smithId : List.copyOf(smiths.keySet())) {
            Entity entity = Bukkit.getEntity(smithId);
            if (entity instanceof Villager villager && villager.isValid()) trackSmith(villager);
            SmithCenter center = smiths.get(smithId);
            if (center == null || !center.worldId().equals(world.getUID())) continue;
            if (Math.abs(block.getX() - center.blockX()) <= radius && Math.abs(block.getZ() - center.blockZ()) <= radius) return true;
        }
        return false;
    }

    private void trackLoadedSmiths(World world) {
        for (Entity entity : world.getEntities()) if (entity instanceof Villager villager) trackSmith(villager);
    }

    private void trackSmiths(Chunk chunk) {
        for (Entity entity : chunk.getEntities()) if (entity instanceof Villager villager) trackSmith(villager);
    }

    private void rememberSmithCenters(Chunk chunk) {
        for (Entity entity : chunk.getEntities()) {
            if (!(entity instanceof Villager villager) || !isSmith(villager)) continue;
            Location location = villager.getLocation();
            smiths.put(villager.getUniqueId(), new SmithCenter(location.getWorld().getUID(), location.getBlockX(), location.getBlockZ()));
        }
    }

    private boolean isSmith(Villager villager) {
        return villager.getPersistentDataContainer().has(smithKey, PersistentDataType.BYTE);
    }

    private void trackPlacedBlock(BlockKey key, org.bukkit.Material expectedType, long placedAt) {
        World world = Bukkit.getWorld(key.worldId());
        if (world == null || !world.isChunkLoaded(key.x() >> 4, key.z() >> 4)) return;
        Block block = world.getBlockAt(key.x(), key.y(), key.z());
        if (block.getType() != expectedType || block.getType().isAir()) return;
        long lifetimeMillis = Math.max(1L, plugin.getConfig().getLong("mace_smith_zone.placed_block_lifetime_seconds", 180)) * 1000L;
        TemporaryBlock temporary = new TemporaryBlock(block.getBlockData().getAsString(), placedAt + lifetimeMillis);
        temporaryBlocks.put(key, temporary);
        saveTemporaryBlocks();
        scheduleExpiry(key);
    }

    private void scheduleExpiry(BlockKey key) {
        BukkitTask previous = expiryTasks.remove(key);
        if (previous != null) previous.cancel();
        TemporaryBlock temporary = temporaryBlocks.get(key);
        if (temporary == null) return;
        World world = Bukkit.getWorld(key.worldId());
        if (world == null || !world.isChunkLoaded(key.x() >> 4, key.z() >> 4)) return;
        long remainingMillis = temporary.expiresAtMillis() - System.currentTimeMillis();
        long delayTicks = Math.max(1L, (remainingMillis + 49L) / 50L);
        expiryTasks.put(key, Bukkit.getScheduler().runTaskLater(plugin, () -> expire(key), delayTicks));
    }

    private void expire(BlockKey key) {
        expiryTasks.remove(key);
        TemporaryBlock temporary = temporaryBlocks.get(key);
        if (temporary == null) return;
        World world = Bukkit.getWorld(key.worldId());
        if (world == null || !world.isChunkLoaded(key.x() >> 4, key.z() >> 4)) return;
        if (System.currentTimeMillis() < temporary.expiresAtMillis()) {
            scheduleExpiry(key);
            return;
        }
        Block block = world.getBlockAt(key.x(), key.y(), key.z());
        if (block.getBlockData().getAsString().equals(temporary.blockData())) {
            BlockState state = block.getState();
            if (state instanceof Container container) container.getInventory().clear();
            XMaterial.matchXMaterial("AIR").map(XMaterial::parseMaterial).ifPresent(air -> block.setType(air, false));
        }
        temporaryBlocks.remove(key);
        saveTemporaryBlocks();
    }

    private void scheduleChunkBlocks(Chunk chunk) {
        UUID worldId = chunk.getWorld().getUID();
        int chunkX = chunk.getX();
        int chunkZ = chunk.getZ();
        for (BlockKey key : temporaryBlocks.keySet()) {
            if (key.worldId().equals(worldId) && (key.x() >> 4) == chunkX && (key.z() >> 4) == chunkZ) scheduleExpiry(key);
        }
    }

    private void loadTemporaryBlocks() {
        if (!dataFile.exists()) return;
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(dataFile);
        for (Map<?, ?> stored : yaml.getMapList("blocks")) {
            try {
                BlockKey key = new BlockKey(UUID.fromString(String.valueOf(stored.get("world"))),
                        ((Number) stored.get("x")).intValue(), ((Number) stored.get("y")).intValue(), ((Number) stored.get("z")).intValue());
                String blockData = String.valueOf(stored.get("block_data"));
                long expiresAt = ((Number) stored.get("expires_at_millis")).longValue();
                if (blockData.isBlank() || expiresAt <= 0L) continue;
                temporaryBlocks.put(key, new TemporaryBlock(blockData, expiresAt));
            } catch (RuntimeException exception) {
                plugin.getLogger().warning("Skipping invalid temporary block entry in mace_smith_zone.yml.");
            }
        }
        for (BlockKey key : List.copyOf(temporaryBlocks.keySet())) scheduleExpiry(key);
    }

    private void saveTemporaryBlocks() {
        YamlConfiguration yaml = new YamlConfiguration();
        List<Map<String, Object>> storedBlocks = new ArrayList<>();
        for (Map.Entry<BlockKey, TemporaryBlock> entry : temporaryBlocks.entrySet()) {
            BlockKey key = entry.getKey();
            Map<String, Object> stored = new HashMap<>();
            stored.put("world", key.worldId().toString());
            stored.put("x", key.x());
            stored.put("y", key.y());
            stored.put("z", key.z());
            stored.put("block_data", entry.getValue().blockData());
            stored.put("expires_at_millis", entry.getValue().expiresAtMillis());
            storedBlocks.add(stored);
        }
        yaml.set("blocks", storedBlocks);
        try {
            yaml.save(dataFile);
        } catch (IOException exception) {
            plugin.getLogger().severe("Could not save mace_smith_zone.yml: " + exception.getMessage());
        }
    }

    private record SmithCenter(UUID worldId, int blockX, int blockZ) { }
    private record BlockKey(UUID worldId, int x, int y, int z) {
        private static BlockKey of(Block block) {
            return new BlockKey(block.getWorld().getUID(), block.getX(), block.getY(), block.getZ());
        }
    }
    private record TemporaryBlock(String blockData, long expiresAtMillis) { }
}
package com.example.projectstructure;

import org.bukkit.plugin.java.JavaPlugin;

public final class ProjectStructurePlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getLogger().info("ProjectStructure enabled.");
    }

    @Override
    public void onDisable() {
        getLogger().info("ProjectStructure disabled.");
    }
}
# MaceProgression

Paper 1.21.11 / Java 21 plugin project. Player data is stored in `players.yml`; tier requirements, enchantments, messages, anti-farming, and locator settings are in `config.yml`.

## Build and install

In Kodari, use **Compile** in the top bar (or **⋮ → Compile Project** on mobile), then download the successful build and place the JAR in the server's `plugins` folder. Restart the server.

## Current implementation

The project implements tier progression, owner-bound maces, configured abilities, kill anti-farming, the Mace Smith Rainbow trade, locator handling, and crafting/storage protections. The root `assets/` folder and `pack.mcmeta` form the resource-pack source; `legacy-pack-assets/` is archival and must not be included in the pack.

## Resource pack

Compile generates `build/distributions/MaceProgression-ResourcePack-1.0.0.zip` with `pack.mcmeta` and `assets/` at the ZIP root. It includes the mace textures, models, and existing animated texture metadata; it excludes `legacy-pack-assets/` and does not override vanilla assets. Upload the ZIP to a public HTTPS URL and set `resource_pack.url` and `resource_pack.sha1` in `config.yml`; the SHA-1 must be the hash of the exact final ZIP. Change the URL (for example, append `?v=2`) every time the ZIP changes so clients do not keep a cached copy. An empty URL means the plugin cannot send the pack.

To isolate pack-side model loading in game, run `/give @s mace[item_model="maceprogression:copper_mace"]`. If that fails while the plugin textures are missing, verify the pack ZIP layout, URL, and SHA-1 first.

## Test checklist

1. Join with an empty inventory and verify a Default Mace is issued.
2. Make 12 valid player kills using the mace. The default progression is 1, 1, 1, 2, 2, 2, and 3 kills per step; the total to Netherite is 12.
3. Kill a player without holding your own plugin mace and verify it does not count. Check repeated-victim, teammate, and same-IP exclusions with anti-farming enabled.
4. Verify the waypoint receive range is disabled below the configured unlock tier and restored at/above it. Test again after respawn and `/mace reload`.
5. Try crafting, smithing, anvil, grindstone, and enchanting operations with a plugin mace; the operations should be blocked.
6. Test `/mace info`, `/mace top`, `/mace set`, `/mace reset`, `/mace give`, and `/mace reload` as an administrator.

## Compatibility notes

This targets Paper 1.21.11. Verify the item model parent/texture UV mapping, abilities, villager trade, and resource-pack acceptance in a live client/server before production.